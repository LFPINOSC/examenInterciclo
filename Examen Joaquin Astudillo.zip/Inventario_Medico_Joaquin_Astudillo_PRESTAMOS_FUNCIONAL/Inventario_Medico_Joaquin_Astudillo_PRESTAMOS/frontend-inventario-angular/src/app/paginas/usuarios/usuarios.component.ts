import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UsuariosService } from '../../nucleo/servicios/usuarios.service';
import { EstadoUsuario, Usuario } from '../../nucleo/modelos/usuario.model';

@Component({selector:'app-usuarios',standalone:true,imports:[CommonModule],templateUrl:'./usuarios.component.html'})
export class UsuariosComponent implements OnInit{
  lista:Usuario[]=[];error='';mensaje='';
  constructor(private api:UsuariosService){}
  ngOnInit(){this.cargar();}
  cargar(){this.api.listar().subscribe({next:r=>this.lista=r,error:e=>this.error=e.error?.mensaje||'No se pudieron cargar los usuarios'});}
  cambiar(u:Usuario,estado:EstadoUsuario){this.api.cambiarEstado(u.id,estado).subscribe({next:()=>{this.mensaje=`Usuario actualizado a ${estado}`;this.cargar();},error:e=>this.error=e.error?.mensaje||'No se pudo actualizar'});}
}
