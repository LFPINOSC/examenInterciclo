import {Component,OnInit} from '@angular/core';
import {CommonModule} from '@angular/common';
import {AutenticacionService} from '../../nucleo/servicios/autenticacion.service';
import {EquipoMedicoService} from '../../nucleo/servicios/equipos.service';
import {CategoriaService} from '../../nucleo/servicios/categorias.service';
import {AreaMedicaService} from '../../nucleo/servicios/areas.service';
@Component({selector:'app-inicio',standalone:true,imports:[CommonModule],templateUrl:'./inicio.component.html'})
export class InicioComponent implements OnInit{
 usuario=this.auth.usuarioActual();totales={equipos:0,unidades:0,categorias:0,areas:0,fueraServicio:0,enUso:0,misPrestamos:0};error='';
 constructor(private auth:AutenticacionService,private equipos:EquipoMedicoService,private categorias:CategoriaService,private areas:AreaMedicaService){}
 ngOnInit(){
  this.equipos.listar().subscribe({next:r=>{this.totales.equipos=r.length;this.totales.unidades=r.reduce((n,e)=>n+e.cantidad,0);this.totales.fueraServicio=r.filter(e=>e.estado==='FUERA_DE_SERVICIO').length;this.totales.enUso=r.filter(e=>e.estado==='EN_USO').length;this.totales.misPrestamos=r.filter(e=>e.prestadoPorId===this.usuario?.id).length;},error:()=>this.error='No se pudieron consultar los equipos'});
  this.categorias.listar().subscribe({next:r=>this.totales.categorias=r.length,error:()=>this.error='No se pudieron consultar las categorías'});
  this.areas.listar().subscribe({next:r=>this.totales.areas=r.length,error:()=>this.error='No se pudieron consultar las áreas'});
 }
}
