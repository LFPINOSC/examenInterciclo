import {Component,OnInit} from '@angular/core';
import {CommonModule} from '@angular/common';
import {OnDestroy} from '@angular/core';
import {interval,Subscription} from 'rxjs';
import {FormBuilder,ReactiveFormsModule,Validators} from '@angular/forms';
import {EquipoMedico,EstadoEquipo,Categoria,AreaMedica} from '../../nucleo/modelos/inventario.model';
import {EquipoMedicoService} from '../../nucleo/servicios/equipos.service';
import {CategoriaService} from '../../nucleo/servicios/categorias.service';
import {AreaMedicaService} from '../../nucleo/servicios/areas.service';
import {AutenticacionService} from '../../nucleo/servicios/autenticacion.service';
@Component({selector:'app-equipos',standalone:true,imports:[CommonModule,ReactiveFormsModule],templateUrl:'./equipos.component.html'})
export class EquiposComponent implements OnInit, OnDestroy {
 private actualizacion?:Subscription;ocupadoId:number|null=null;
 lista:EquipoMedico[]=[];categorias:Categoria[]=[];areas:AreaMedica[]=[];editando:number|null=null;error='';mensaje='';busqueda='';
 estados:EstadoEquipo[]=['DISPONIBLE','EN_USO','FUERA_DE_SERVICIO'];
 form=this.fb.nonNullable.group({
  codigo:['',[Validators.required,Validators.maxLength(30)]],nombre:['',[Validators.required,Validators.maxLength(120)]],
  marca:['',[Validators.required,Validators.maxLength(80)]],modelo:['',[Validators.required,Validators.maxLength(80)]],
  numeroSerie:[''],cantidad:[1,[Validators.required,Validators.min(1)]],fechaAdquisicion:[''],
  estado:['DISPONIBLE' as EstadoEquipo,Validators.required],categoriaId:[0,[Validators.required,Validators.min(1)]],areaId:[0,[Validators.required,Validators.min(1)]]
 });
 constructor(private fb:FormBuilder,private api:EquipoMedicoService,private cats:CategoriaService,private areasApi:AreaMedicaService,public auth:AutenticacionService){}
 ngOnInit(){this.cargar();this.actualizacion=interval(10000).subscribe(()=>this.cargar(true));this.cats.listar().subscribe({next:r=>this.categorias=r,error:()=>this.error='No se pudieron cargar las categorías'});this.areasApi.listar().subscribe({next:r=>this.areas=r,error:()=>this.error='No se pudieron cargar las áreas'});}
 ngOnDestroy(){this.actualizacion?.unsubscribe();}
 get miId(){return this.auth.usuarioActual()?.id;}
 get filtrados(){const q=this.busqueda.toLocaleLowerCase().trim();return !q?this.lista:this.lista.filter(e=>[e.codigo,e.nombre,e.marca,e.modelo,e.categoria.nombre,e.area.nombre,e.estado,e.prestadoPorNombre||''].some(x=>x.toLowerCase().includes(q)));}
 cargar(silencioso=false){this.api.listar().subscribe({next:r=>this.lista=r,error:e=>{if(!silencioso)this.error=e.error?.mensaje||'No se pudieron cargar los equipos';}});}
 guardar(){this.error='';this.mensaje='';if(this.form.invalid){this.form.markAllAsTouched();this.error='Completa los campos obligatorios y selecciona categoría y área.';return;}
  const v=this.form.getRawValue();const d:EquipoMedico={codigo:v.codigo.trim(),nombre:v.nombre.trim(),marca:v.marca.trim(),modelo:v.modelo.trim(),numeroSerie:v.numeroSerie.trim()||null,cantidad:v.cantidad,fechaAdquisicion:v.fechaAdquisicion||null,estado:v.estado,categoria:{id:v.categoriaId,nombre:''},area:{id:v.areaId,nombre:''}};
  const op=this.editando!==null?this.api.actualizar(this.editando,d):this.api.crear(d);
  op.subscribe({next:()=>{this.mensaje=this.editando!==null?'Equipo actualizado':'Equipo registrado';this.cancelar();this.cargar();},error:e=>this.error=e.error?.mensaje||(e.status===403?'No tienes permisos para modificar equipos':'No se pudo guardar el equipo')});
 }
 solicitar(e:EquipoMedico){
  if(!e.id||e.estado!=='DISPONIBLE'||this.ocupadoId!==null)return;
  if(!confirm(`¿Solicitar prestado el equipo ${e.nombre} (${e.codigo})?`))return;
  this.error='';this.mensaje='';this.ocupadoId=e.id;
  this.api.solicitarPrestamo(e.id).subscribe({next:()=>{this.ocupadoId=null;this.mensaje=`Préstamo confirmado: ${e.nombre} está EN USO a tu nombre.`;this.cargar();},error:err=>{this.ocupadoId=null;this.error=err.error?.mensaje||'No se pudo solicitar el préstamo';this.cargar();}});
 }
 devolver(e:EquipoMedico){
  if(!e.id||this.ocupadoId!==null)return;
  if(!confirm(`¿Registrar la devolución del equipo ${e.nombre}?`))return;
  this.error='';this.mensaje='';this.ocupadoId=e.id;
  this.api.devolverPrestamo(e.id).subscribe({next:()=>{this.ocupadoId=null;this.mensaje=`Devolución confirmada: ${e.nombre} está DISPONIBLE.`;this.cargar();},error:err=>{this.ocupadoId=null;this.error=err.error?.mensaje||'No se pudo devolver el equipo';this.cargar();}});
 }
 editar(e:EquipoMedico){this.editando=e.id!;this.form.patchValue({codigo:e.codigo,nombre:e.nombre,marca:e.marca,modelo:e.modelo,numeroSerie:e.numeroSerie||'',cantidad:e.cantidad,fechaAdquisicion:e.fechaAdquisicion||'',estado:e.estado,categoriaId:e.categoria.id!,areaId:e.area.id!});window.scrollTo({top:0,behavior:'smooth'});}
 cancelar(){this.editando=null;this.form.reset({codigo:'',nombre:'',marca:'',modelo:'',numeroSerie:'',cantidad:1,fechaAdquisicion:'',estado:'DISPONIBLE',categoriaId:0,areaId:0});}
 eliminar(e:EquipoMedico){if(confirm(`¿Eliminar el equipo ${e.nombre}?`))this.api.eliminar(e.id!).subscribe({next:()=>{this.mensaje='Equipo eliminado';this.cargar();},error:err=>this.error=err.error?.mensaje||'No se pudo eliminar'});}
}
