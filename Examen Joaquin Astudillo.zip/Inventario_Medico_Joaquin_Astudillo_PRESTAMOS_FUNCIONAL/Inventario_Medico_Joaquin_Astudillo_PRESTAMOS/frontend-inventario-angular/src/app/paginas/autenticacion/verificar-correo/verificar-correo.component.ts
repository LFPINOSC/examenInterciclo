import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AutenticacionService } from '../../../nucleo/servicios/autenticacion.service';

@Component({selector:'app-verificar-correo',standalone:true,imports:[CommonModule,ReactiveFormsModule],templateUrl:'./verificar-correo.component.html'})
export class VerificarCorreoComponent{
  correo=sessionStorage.getItem('correo_verificacion')||''; mensaje=''; error='';
  form=this.fb.nonNullable.group({codigo:['',[Validators.required,Validators.pattern(/^\d{6}$/)]]});
  constructor(private fb:FormBuilder,private auth:AutenticacionService,private router:Router){}
  verificar(){if(this.form.invalid){this.form.markAllAsTouched();return;}this.error='';
    this.auth.verificar(this.correo,this.form.controls.codigo.value).subscribe({next:()=>this.router.navigate(['/pendiente-aprobacion']),error:e=>this.error=e.error?.mensaje||'Código inválido'});
  }
  reenviar(){this.mensaje='';this.error='';this.auth.reenviarCodigo(this.correo).subscribe({next:()=>{this.mensaje='Se envió un nuevo código a tu correo.';},error:e=>this.error=e.error?.mensaje||'No se pudo reenviar'});}
}
