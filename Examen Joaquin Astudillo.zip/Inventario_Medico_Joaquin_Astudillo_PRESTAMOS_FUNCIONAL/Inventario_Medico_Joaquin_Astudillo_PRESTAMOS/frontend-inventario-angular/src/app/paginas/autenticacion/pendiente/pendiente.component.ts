import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';
@Component({selector:'app-pendiente',standalone:true,imports:[RouterLink],templateUrl:'./pendiente.component.html'})
export class PendienteComponent{}
