import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { AutenticacionService } from '../../../nucleo/servicios/autenticacion.service';

@Component({
  selector:'app-login', standalone:true,
  imports:[CommonModule,ReactiveFormsModule,RouterLink],
  templateUrl:'./login.component.html'
})
export class LoginComponent {
  cargando=false; error='';
  form=this.fb.nonNullable.group({email:['',[Validators.required,Validators.email]],password:['',Validators.required]});
  constructor(private fb:FormBuilder,private auth:AutenticacionService,private router:Router){}
  entrar(){
    if(this.form.invalid){this.form.markAllAsTouched();return;}
    this.cargando=true;this.error='';
    this.auth.login(this.form.controls.email.value,this.form.controls.password.value).subscribe({
      next:()=>this.router.navigate(['/inicio']),
      error:e=>{this.cargando=false;this.error=e.error?.mensaje||'No se pudo iniciar sesión';}
    });
  }
}
