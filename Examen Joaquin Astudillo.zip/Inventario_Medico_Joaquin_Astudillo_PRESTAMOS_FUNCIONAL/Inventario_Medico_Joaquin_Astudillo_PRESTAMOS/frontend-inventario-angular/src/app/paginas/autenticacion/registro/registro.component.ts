import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { AutenticacionService } from '../../../nucleo/servicios/autenticacion.service';

@Component({selector:'app-registro',standalone:true,imports:[CommonModule,ReactiveFormsModule,RouterLink],templateUrl:'./registro.component.html'})
export class RegistroComponent{
  error='';cargando=false;
  form=this.fb.nonNullable.group({
    nombre:['',[Validators.required,Validators.minLength(3),Validators.maxLength(120)]],
    email:['',[Validators.required,Validators.email]],
    telefono:['',[Validators.required,Validators.pattern(/^[0-9+ -]{7,20}$/)]],
    password:['',[Validators.required,Validators.minLength(8),Validators.pattern(/^(?=.*[A-Za-z])(?=.*\d).+$/)]]
  });
  constructor(private fb:FormBuilder,private auth:AutenticacionService,private router:Router){}
  registrar(){if(this.form.invalid){this.form.markAllAsTouched();return;}this.cargando=true;this.error='';
    this.auth.registrar(this.form.getRawValue()).subscribe({next:()=>{
      sessionStorage.setItem('correo_verificacion',this.form.controls.email.value);
      this.router.navigate(['/verificar-correo']);
    },error:e=>{this.cargando=false;this.error=e.error?.mensaje||'No se pudo registrar';}});
  }
}
