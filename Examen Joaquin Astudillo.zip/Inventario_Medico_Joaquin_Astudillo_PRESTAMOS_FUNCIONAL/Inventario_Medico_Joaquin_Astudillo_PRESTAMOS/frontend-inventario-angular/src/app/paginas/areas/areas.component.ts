import {Component,OnInit} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FormBuilder,ReactiveFormsModule,Validators} from '@angular/forms';
import {AreaMedicaService} from '../../nucleo/servicios/areas.service';
import {AutenticacionService} from '../../nucleo/servicios/autenticacion.service';
import {AreaMedica} from '../../nucleo/modelos/inventario.model';
@Component({selector:'app-areas',standalone:true,imports:[CommonModule,ReactiveFormsModule],templateUrl:'./areas.component.html'})
export class AreasComponent implements OnInit {
 lista:AreaMedica[]=[]; editando:number|null=null;error='';mensaje='';
 form=this.fb.nonNullable.group({nombre:['',Validators.required],responsable:[''],descripcion:['']});
 constructor(private fb:FormBuilder,private api:AreaMedicaService,public auth:AutenticacionService){}
 ngOnInit(){this.cargar();}
 cargar(){this.api.listar().subscribe({next:r=>this.lista=r,error:e=>this.error=e.error?.mensaje||'Error al consultar registros'});}
 guardar(){this.error='';this.mensaje='';if(this.form.invalid){this.form.markAllAsTouched();return;}
 const d=this.form.getRawValue();const op=this.editando!==null?this.api.actualizar(this.editando,d):this.api.crear(d);
 op.subscribe({next:()=>{this.mensaje='Registro guardado correctamente';this.cancelar();this.cargar();},error:e=>this.error=e.error?.mensaje||'Error al guardar'});}
 editar(d:AreaMedica){this.editando=d.id!;this.form.patchValue({nombre:d.nombre||'',responsable:d.responsable||'',descripcion:d.descripcion||''});window.scrollTo({top:0,behavior:'smooth'});}
 cancelar(){this.editando=null;this.form.reset({nombre:'',responsable:'',descripcion:''});}
 eliminar(d:AreaMedica){if(confirm(`¿Eliminar ${d.nombre}?`))this.api.eliminar(d.id!).subscribe({next:()=>{this.mensaje='Registro eliminado';this.cargar();},error:e=>this.error=e.error?.mensaje||'No se puede eliminar'});}
}
