import { Component } from '@angular/core';
import { AsyncPipe, NgIf } from '@angular/common';
import { Router, RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { AutenticacionService } from '../../nucleo/servicios/autenticacion.service';

@Component({
  selector: 'app-layout', standalone: true,
  imports: [RouterOutlet, RouterLink, RouterLinkActive, AsyncPipe, NgIf],
  templateUrl: './layout.component.html'
})
export class LayoutComponent {
  usuario$ = this.auth.usuario$;
  constructor(public auth: AutenticacionService, private router: Router) {}
  salir() { this.auth.logout(); this.router.navigate(['/iniciar-sesion']); }
}
