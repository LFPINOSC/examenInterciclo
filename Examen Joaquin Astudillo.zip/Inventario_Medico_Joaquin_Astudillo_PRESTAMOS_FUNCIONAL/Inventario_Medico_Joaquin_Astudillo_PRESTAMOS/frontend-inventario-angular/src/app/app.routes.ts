import { Routes } from '@angular/router';
import { autenticacionGuard } from './nucleo/guardias/autenticacion.guard';
import { administradorGuard } from './nucleo/guardias/administrador.guard';
import { LayoutComponent } from './compartido/layout/layout.component';
import { LoginComponent } from './paginas/autenticacion/login/login.component';
import { RegistroComponent } from './paginas/autenticacion/registro/registro.component';
import { VerificarCorreoComponent } from './paginas/autenticacion/verificar-correo/verificar-correo.component';
import { PendienteComponent } from './paginas/autenticacion/pendiente/pendiente.component';
import { InicioComponent } from './paginas/inicio/inicio.component';
import { EquiposComponent } from './paginas/equipos/equipos.component';
import { CategoriasComponent } from './paginas/categorias/categorias.component';
import { AreasComponent } from './paginas/areas/areas.component';
import { UsuariosComponent } from './paginas/usuarios/usuarios.component';
export const routes:Routes=[
 {path:'iniciar-sesion',component:LoginComponent},
 {path:'registro',component:RegistroComponent},
 {path:'verificar-correo',component:VerificarCorreoComponent},
 {path:'pendiente-aprobacion',component:PendienteComponent},
 {path:'',component:LayoutComponent,canActivate:[autenticacionGuard],children:[
  {path:'inicio',component:InicioComponent},
  {path:'equipos',component:EquiposComponent},
  {path:'categorias',component:CategoriasComponent},
  {path:'areas',component:AreasComponent},
  {path:'usuarios',component:UsuariosComponent,canActivate:[administradorGuard]},
  {path:'',pathMatch:'full',redirectTo:'inicio'}
 ]},
 {path:'**',redirectTo:'inicio'}
];
