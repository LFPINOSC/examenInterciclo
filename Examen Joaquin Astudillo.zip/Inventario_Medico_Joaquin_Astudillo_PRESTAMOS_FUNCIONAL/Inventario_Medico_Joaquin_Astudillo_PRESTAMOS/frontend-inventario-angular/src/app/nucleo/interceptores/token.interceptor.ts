import { HttpInterceptorFn, HttpErrorResponse } from '@angular/common/http';
import { inject } from '@angular/core';
import { Router } from '@angular/router';
import { catchError, throwError } from 'rxjs';
import { AutenticacionService } from '../servicios/autenticacion.service';

export const tokenInterceptor: HttpInterceptorFn = (req, next) => {
  const auth = inject(AutenticacionService);
  const router = inject(Router);
  const token = auth.token();
  const solicitud = token ? req.clone({ setHeaders: { Authorization: `Bearer ${token}` } }) : req;

  return next(solicitud).pipe(catchError((error: HttpErrorResponse) => {
    if (error.status === 401 && token) {
      auth.logout();
      router.navigate(['/iniciar-sesion']);
    }
    return throwError(() => error);
  }));
};
