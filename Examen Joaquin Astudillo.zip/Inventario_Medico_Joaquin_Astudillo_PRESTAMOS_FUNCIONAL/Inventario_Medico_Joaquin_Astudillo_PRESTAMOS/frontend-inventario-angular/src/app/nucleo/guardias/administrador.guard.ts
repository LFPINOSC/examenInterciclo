import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AutenticacionService } from '../servicios/autenticacion.service';

export const administradorGuard: CanActivateFn = () => {
  const auth = inject(AutenticacionService);
  const router = inject(Router);
  return auth.esAdmin() ? true : router.createUrlTree(['/inicio']);
};
