export interface Categoria {id?:number;nombre:string;descripcion?:string;}
export interface AreaMedica {id?:number;nombre:string;responsable?:string;descripcion?:string;}
export type EstadoEquipo='DISPONIBLE'|'EN_USO'|'FUERA_DE_SERVICIO';
export interface EquipoMedico {
 id?:number; codigo:string;nombre:string;marca:string;modelo:string;numeroSerie?:string|null;
 cantidad:number;fechaAdquisicion?:string|null;estado:EstadoEquipo;
 categoria:Categoria;area:AreaMedica;
 prestadoPorId?:number|null;prestadoPorNombre?:string|null;prestadoEn?:string|null;
}
