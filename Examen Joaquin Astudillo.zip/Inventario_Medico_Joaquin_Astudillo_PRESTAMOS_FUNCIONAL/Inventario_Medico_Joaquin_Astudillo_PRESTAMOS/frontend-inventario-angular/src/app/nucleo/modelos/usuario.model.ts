export type Rol = 'USER' | 'ADMIN';
export type EstadoUsuario = 'PENDIENTE' | 'APROBADA' | 'RECHAZADA' | 'BLOQUEADA';

export interface Usuario {
  id: number;
  nombre: string;
  email: string;
  telefono: string;
  rol: Rol;
  estado: EstadoUsuario;
  verificada: boolean;
}

export interface AuthResponse {
  ok: boolean;
  mensaje: string;
  token: string;
  usuario: Usuario;
}
