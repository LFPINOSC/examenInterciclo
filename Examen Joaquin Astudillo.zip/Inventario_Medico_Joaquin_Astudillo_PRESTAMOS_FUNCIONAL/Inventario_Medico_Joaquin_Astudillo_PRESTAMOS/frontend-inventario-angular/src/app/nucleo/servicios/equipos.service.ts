import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {API_URL} from '../../config/api.config';
import {EquipoMedico} from '../modelos/inventario.model';
@Injectable({providedIn:'root'})
export class EquipoMedicoService {
 private url=`${API_URL}/equipos`;
 constructor(private http:HttpClient){}
 listar(){return this.http.get<EquipoMedico[]>(this.url);}
 buscar(id:number){return this.http.get<EquipoMedico>(`${this.url}/${id}`);}
 crear(datos:EquipoMedico){return this.http.post<EquipoMedico>(this.url,datos);}
 actualizar(id:number,datos:EquipoMedico){return this.http.put<EquipoMedico>(`${this.url}/${id}`,datos);}
 solicitarPrestamo(id:number){return this.http.post<EquipoMedico>(`${this.url}/${id}/prestar`,{});}
 devolverPrestamo(id:number){return this.http.post<EquipoMedico>(`${this.url}/${id}/devolver`,{});}
 eliminar(id:number){return this.http.delete<void>(`${this.url}/${id}`);}
}
