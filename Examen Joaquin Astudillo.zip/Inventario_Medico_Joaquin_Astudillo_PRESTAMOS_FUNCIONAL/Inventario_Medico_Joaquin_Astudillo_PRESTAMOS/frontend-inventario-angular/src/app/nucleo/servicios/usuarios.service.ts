import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { API_URL } from '../../config/api.config';
import { EstadoUsuario, Usuario } from '../modelos/usuario.model';

@Injectable({ providedIn: 'root' })
export class UsuariosService {
  constructor(private http: HttpClient) {}
  listar() { return this.http.get<Usuario[]>(`${API_URL}/admin/usuarios`); }
  pendientes() { return this.http.get<Usuario[]>(`${API_URL}/admin/usuarios/pendientes`); }
  cambiarEstado(id: number, estado: EstadoUsuario) {
    return this.http.patch<Usuario>(`${API_URL}/admin/usuarios/${id}/estado`, { estado });
  }
}
