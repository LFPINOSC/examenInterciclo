import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, tap } from 'rxjs';
import { API_URL } from '../../config/api.config';
import { AuthResponse, Usuario } from '../modelos/usuario.model';

@Injectable({ providedIn: 'root' })
export class AutenticacionService {
  private readonly TOKEN = 'inventario_medico_token';
  private readonly USUARIO = 'inventario_medico_usuario';
  private usuarioSubject = new BehaviorSubject<Usuario | null>(this.leerUsuario());
  usuario$ = this.usuarioSubject.asObservable();

  constructor(private http: HttpClient) {}

  registrar(datos: {nombre:string; email:string; password:string; telefono:string}) {
    return this.http.post<any>(`${API_URL}/auth/registro`, datos);
  }
  verificar(email: string, codigo: string) {
    return this.http.post<Usuario>(`${API_URL}/auth/verificar`, { email, codigo });
  }
  reenviarCodigo(email: string) {
    return this.http.post<any>(`${API_URL}/auth/reenviar-codigo`, { email });
  }
  login(email: string, password: string) {
    return this.http.post<AuthResponse>(`${API_URL}/auth/login`, { email, password }).pipe(
      tap(r => this.guardarSesion(r))
    );
  }
  perfil() { return this.http.get<Usuario>(`${API_URL}/auth/perfil`); }
  logout() {
    localStorage.removeItem(this.TOKEN);
    localStorage.removeItem(this.USUARIO);
    this.usuarioSubject.next(null);
  }
  token() { return localStorage.getItem(this.TOKEN); }
  usuarioActual() { return this.usuarioSubject.value; }
  estaAutenticado() { return !!this.token() && !!this.usuarioActual(); }
  esAdmin() { return this.usuarioActual()?.rol === 'ADMIN'; }

  private guardarSesion(r: AuthResponse) {
    localStorage.setItem(this.TOKEN, r.token);
    localStorage.setItem(this.USUARIO, JSON.stringify(r.usuario));
    this.usuarioSubject.next(r.usuario);
  }
  private leerUsuario(): Usuario | null {
    const raw = localStorage.getItem(this.USUARIO);
    try { return raw ? JSON.parse(raw) as Usuario : null; } catch { return null; }
  }
}
