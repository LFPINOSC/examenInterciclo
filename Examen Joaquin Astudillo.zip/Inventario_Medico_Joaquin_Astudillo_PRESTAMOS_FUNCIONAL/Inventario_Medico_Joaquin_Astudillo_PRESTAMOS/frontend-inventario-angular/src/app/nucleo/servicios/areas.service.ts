import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {API_URL} from '../../config/api.config';
import {AreaMedica} from '../modelos/inventario.model';
@Injectable({providedIn:'root'})
export class AreaMedicaService {
 private url=`${API_URL}/areas`;
 constructor(private http:HttpClient){}
 listar(){return this.http.get<AreaMedica[]>(this.url);}
 buscar(id:number){return this.http.get<AreaMedica>(`${this.url}/${id}`);}
 crear(datos:AreaMedica){return this.http.post<AreaMedica>(this.url,datos);}
 actualizar(id:number,datos:AreaMedica){return this.http.put<AreaMedica>(`${this.url}/${id}`,datos);}
 eliminar(id:number){return this.http.delete<void>(`${this.url}/${id}`);}
}
