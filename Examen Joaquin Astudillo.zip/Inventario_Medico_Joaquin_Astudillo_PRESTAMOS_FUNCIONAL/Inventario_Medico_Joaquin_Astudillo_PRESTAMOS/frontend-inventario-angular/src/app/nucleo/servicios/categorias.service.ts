import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {API_URL} from '../../config/api.config';
import {Categoria} from '../modelos/inventario.model';
@Injectable({providedIn:'root'})
export class CategoriaService {
 private url=`${API_URL}/categorias`;
 constructor(private http:HttpClient){}
 listar(){return this.http.get<Categoria[]>(this.url);}
 buscar(id:number){return this.http.get<Categoria>(`${this.url}/${id}`);}
 crear(datos:Categoria){return this.http.post<Categoria>(this.url,datos);}
 actualizar(id:number,datos:Categoria){return this.http.put<Categoria>(`${this.url}/${id}`,datos);}
 eliminar(id:number){return this.http.delete<void>(`${this.url}/${id}`);}
}
