-- SOLO REFERENCIA DE DISEÑO. Si Spring Boot ya creó las tablas, NO hace falta ejecutar.
CREATE DATABASE IF NOT EXISTS inventario_medico_joaquin CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE inventario_medico_joaquin;

CREATE TABLE IF NOT EXISTS usuarios (
 id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
 nombre VARCHAR(120) NOT NULL,
 email VARCHAR(150) NOT NULL UNIQUE,
 password_hash VARCHAR(120) NOT NULL,
 telefono VARCHAR(25),
 rol VARCHAR(20) NOT NULL,
 estado VARCHAR(20) NOT NULL,
 verificada BOOLEAN NOT NULL,
 codigo_verificacion_hash VARCHAR(64),
 codigo_expira DATETIME(6),
 codigo_generado_en DATETIME(6),
 creado_en DATETIME(6) NOT NULL
);
CREATE TABLE IF NOT EXISTS categorias (
 id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
 nombre VARCHAR(100) NOT NULL UNIQUE,
 descripcion VARCHAR(255)
);
CREATE TABLE IF NOT EXISTS areas_medicas (
 id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
 nombre VARCHAR(100) NOT NULL UNIQUE,
 responsable VARCHAR(120),
 descripcion VARCHAR(255)
);
CREATE TABLE IF NOT EXISTS equipos_medicos (
 id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
 codigo VARCHAR(30) NOT NULL UNIQUE,
 nombre VARCHAR(120) NOT NULL,
 marca VARCHAR(80) NOT NULL,
 modelo VARCHAR(80) NOT NULL,
 numero_serie VARCHAR(100) UNIQUE,
 cantidad INT NOT NULL,
 fecha_adquisicion DATE,
 estado VARCHAR(30) NOT NULL,
 categoria_id BIGINT NOT NULL,
 area_id BIGINT NOT NULL,
 prestado_por_id BIGINT NULL,
 prestado_en DATETIME(6) NULL,
 CONSTRAINT fk_equipo_categoria FOREIGN KEY(categoria_id) REFERENCES categorias(id),
 CONSTRAINT fk_equipo_area FOREIGN KEY(area_id) REFERENCES areas_medicas(id),
 CONSTRAINT fk_equipo_prestatario FOREIGN KEY(prestado_por_id) REFERENCES usuarios(id),
 CONSTRAINT chk_cantidad CHECK(cantidad>=0)
);
