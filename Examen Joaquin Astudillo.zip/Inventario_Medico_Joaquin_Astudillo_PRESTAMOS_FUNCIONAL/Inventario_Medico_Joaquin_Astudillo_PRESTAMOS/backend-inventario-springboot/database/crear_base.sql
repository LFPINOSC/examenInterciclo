CREATE DATABASE IF NOT EXISTS inventario_medico_joaquin CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE inventario_medico_joaquin;
-- Spring Data JPA crea automáticamente SOLO estas 4 tablas al iniciar (ddl-auto=update):
-- usuarios, categorias, areas_medicas y equipos_medicos.
-- Equipos_medicos contiene categoria_id y area_id (claves foraneas).
