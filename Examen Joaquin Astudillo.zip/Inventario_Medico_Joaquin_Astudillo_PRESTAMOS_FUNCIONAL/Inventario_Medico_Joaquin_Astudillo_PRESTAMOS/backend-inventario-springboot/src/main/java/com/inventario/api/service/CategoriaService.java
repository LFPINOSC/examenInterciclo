package com.inventario.api.service;
import com.inventario.api.exception.*;
import com.inventario.api.model.Categoria;
import com.inventario.api.repository.CategoriaRepository;
import com.inventario.api.repository.EquipoMedicoRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import java.util.List;
@Service
public class CategoriaService {
 private final CategoriaRepository repo;
 private final EquipoMedicoRepository equipos;
 public CategoriaService(CategoriaRepository repo,EquipoMedicoRepository equipos){this.repo=repo;this.equipos=equipos;}
 public List<Categoria> listar(){return repo.findAll();}
 public Categoria buscar(Long id){return repo.findById(id).orElseThrow(()->new ResourceNotFoundException("Categoría no encontrada: "+id));}
 public Categoria crear(Categoria datos){datos.setId(null);return repo.save(datos);}
 public Categoria actualizar(Long id,Categoria datos){Categoria actual=buscar(id);actual.setNombre(datos.getNombre()); actual.setDescripcion(datos.getDescripcion()); return repo.save(actual);}
 public void eliminar(Long id){buscar(id);if(equipos.existsByCategoria_Id(id)) throw new ApiException(HttpStatus.CONFLICT,"No se puede eliminar: tiene equipos asociados");repo.deleteById(id);}
}
