package com.inventario.api.model;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
@Entity @Table(name="equipos_medicos")
public class EquipoMedico {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 @NotBlank @Size(max=30) @Column(nullable=false,unique=true,length=30) private String codigo;
 @NotBlank @Size(max=120) @Column(nullable=false,length=120) private String nombre;
 @NotBlank @Size(max=80) @Column(nullable=false,length=80) private String marca;
 @NotBlank @Size(max=80) @Column(nullable=false,length=80) private String modelo;
 @Size(max=100) @Column(name="numero_serie",unique=true,length=100) private String numeroSerie;
 @NotNull @Min(0) @Column(nullable=false) private Integer cantidad=1;
 private LocalDate fechaAdquisicion;
 @NotNull @Enumerated(EnumType.STRING) @Column(nullable=false,length=30) private EstadoEquipo estado=EstadoEquipo.DISPONIBLE;
 @NotNull @ManyToOne(fetch=FetchType.EAGER,optional=false) @JoinColumn(name="categoria_id",nullable=false) private Categoria categoria;
 @NotNull @ManyToOne(fetch=FetchType.EAGER,optional=false) @JoinColumn(name="area_id",nullable=false) private AreaMedica area;
 // Relación con Usuario: guarda quién tiene actualmente prestado el equipo. NO crea otra tabla.
 @JsonIgnore @ManyToOne(fetch=FetchType.EAGER) @JoinColumn(name="prestado_por_id") private Usuario prestadoPor;
 @Column(name="prestado_en") private LocalDateTime prestadoEn;
 @JsonProperty("prestadoPorId") public Long getPrestadoPorId(){return prestadoPor==null?null:prestadoPor.getId();}
 @JsonProperty("prestadoPorNombre") public String getPrestadoPorNombre(){return prestadoPor==null?null:prestadoPor.getNombre();}
 public Usuario getPrestadoPor(){return prestadoPor;} public void setPrestadoPor(Usuario v){prestadoPor=v;}
 public LocalDateTime getPrestadoEn(){return prestadoEn;} public void setPrestadoEn(LocalDateTime v){prestadoEn=v;}
 public Long getId(){return id;} public void setId(Long v){id=v;}
 public String getCodigo(){return codigo;} public void setCodigo(String v){codigo=v;}
 public String getNombre(){return nombre;} public void setNombre(String v){nombre=v;}
 public String getMarca(){return marca;} public void setMarca(String v){marca=v;}
 public String getModelo(){return modelo;} public void setModelo(String v){modelo=v;}
 public String getNumeroSerie(){return numeroSerie;} public void setNumeroSerie(String v){numeroSerie=v;}
 public Integer getCantidad(){return cantidad;} public void setCantidad(Integer v){cantidad=v;}
 public LocalDate getFechaAdquisicion(){return fechaAdquisicion;} public void setFechaAdquisicion(LocalDate v){fechaAdquisicion=v;}
 public EstadoEquipo getEstado(){return estado;} public void setEstado(EstadoEquipo v){estado=v;}
 public Categoria getCategoria(){return categoria;} public void setCategoria(Categoria v){categoria=v;}
 public AreaMedica getArea(){return area;} public void setArea(AreaMedica v){area=v;}
}
