package com.inventario.api.model;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
@Entity @Table(name="areas_medicas")
public class AreaMedica {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 @NotBlank @Size(max=100) @Column(nullable=false,unique=true,length=100) private String nombre;
 @Size(max=120) private String responsable;
 @Size(max=255) private String descripcion;
 public Long getId(){return id;} public void setId(Long v){id=v;}
 public String getNombre(){return nombre;} public void setNombre(String v){nombre=v;}
 public String getResponsable(){return responsable;} public void setResponsable(String v){responsable=v;}
 public String getDescripcion(){return descripcion;} public void setDescripcion(String v){descripcion=v;}
}
