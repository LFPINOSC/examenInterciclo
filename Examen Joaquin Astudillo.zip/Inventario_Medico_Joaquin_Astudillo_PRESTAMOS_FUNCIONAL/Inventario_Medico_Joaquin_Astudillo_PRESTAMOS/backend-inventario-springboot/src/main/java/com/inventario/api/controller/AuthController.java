package com.inventario.api.controller;

import com.inventario.api.dto.*;
import com.inventario.api.service.*;
import jakarta.validation.Valid;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
public class AuthController {
    private final AuthService auth;
    private final UsuarioActualService actual;
    public AuthController(AuthService auth, UsuarioActualService actual) { this.auth=auth; this.actual=actual; }

    @PostMapping("/registro")
    public ResponseEntity<RegistroResponse> registro(@Valid @RequestBody RegistroRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED).body(auth.registrar(req));
    }
    @PostMapping("/verificar")
    public UsuarioResponse verificar(@Valid @RequestBody VerificarRequest req) { return auth.verificar(req); }
    @PostMapping("/reenviar-codigo")
    public RegistroResponse reenviar(@Valid @RequestBody ReenviarCodigoRequest req) { return auth.reenviar(req); }
    @PostMapping("/login")
    public AuthResponse login(@Valid @RequestBody LoginRequest req) { return auth.login(req); }
    @GetMapping("/perfil")
    public UsuarioResponse perfil() { return UsuarioResponse.from(actual.obtener()); }
}
