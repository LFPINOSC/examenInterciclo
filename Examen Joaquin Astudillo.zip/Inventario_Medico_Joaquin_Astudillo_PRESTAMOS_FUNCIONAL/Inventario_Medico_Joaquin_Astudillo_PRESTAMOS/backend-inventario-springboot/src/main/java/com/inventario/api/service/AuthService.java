package com.inventario.api.service;

import com.inventario.api.dto.*;
import com.inventario.api.exception.ApiException;
import com.inventario.api.model.*;
import com.inventario.api.repository.UsuarioRepository;
import com.inventario.api.security.JwtService;
import com.inventario.api.util.CodigoVerificacionUtil;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.*;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.*;

@Service
public class AuthService {
    private final UsuarioRepository repo;
    private final PasswordEncoder encoder;
    private final EmailService emailService;
    private final JwtService jwtService;
    private final AuthenticationManager authenticationManager;
    @Value("${app.verification.expiration-minutes:10}") private long expirationMinutes;
    @Value("${app.verification.resend-seconds:60}") private long resendSeconds;

    public AuthService(UsuarioRepository repo, PasswordEncoder encoder, EmailService emailService,
                       JwtService jwtService, AuthenticationManager authenticationManager) {
        this.repo = repo; this.encoder = encoder; this.emailService = emailService;
        this.jwtService = jwtService; this.authenticationManager = authenticationManager;
    }

    @Transactional
    public RegistroResponse registrar(RegistroRequest r) {
        String email = r.email().trim().toLowerCase();
        if (repo.existsByEmailIgnoreCase(email)) throw new ApiException(HttpStatus.CONFLICT, "Ya existe una cuenta con ese correo");

        Usuario u = new Usuario();
        u.setNombre(r.nombre().trim());
        u.setEmail(email);
        u.setPasswordHash(encoder.encode(r.password()));
        u.setTelefono(r.telefono().trim());
        u.setRol(Rol.USER);
        u.setEstado(EstadoUsuario.PENDIENTE);
        u.setVerificada(false);

        String codigo = CodigoVerificacionUtil.generarCodigo();
        u.setCodigoVerificacionHash(CodigoVerificacionUtil.hash(codigo));
        u.setCodigoGeneradoEn(LocalDateTime.now());
        u.setCodigoExpira(LocalDateTime.now().plusMinutes(expirationMinutes));
        repo.save(u);

        emailService.enviarCodigo(u.getEmail(), u.getNombre(), codigo);
        return new RegistroResponse(true, "Cuenta creada. Revisa tu correo para obtener el código de verificación.", UsuarioResponse.from(u));
    }

    @Transactional
    public UsuarioResponse verificar(VerificarRequest r) {
        Usuario u = buscar(r.email());
        if (u.isVerificada()) return UsuarioResponse.from(u);
        if (u.getCodigoExpira() == null || LocalDateTime.now().isAfter(u.getCodigoExpira()))
            throw new ApiException(HttpStatus.BAD_REQUEST, "El código expiró. Solicita uno nuevo.");
        if (!CodigoVerificacionUtil.hash(r.codigo()).equals(u.getCodigoVerificacionHash()))
            throw new ApiException(HttpStatus.BAD_REQUEST, "Código de verificación incorrecto");
        u.setVerificada(true);
        u.setCodigoVerificacionHash(null);
        u.setCodigoExpira(null);
        repo.save(u);
        return UsuarioResponse.from(u);
    }

    @Transactional
    public RegistroResponse reenviar(ReenviarCodigoRequest r) {
        Usuario u = buscar(r.email());
        if (u.isVerificada()) throw new ApiException(HttpStatus.CONFLICT, "La cuenta ya está verificada");
        if (u.getCodigoGeneradoEn() != null && LocalDateTime.now().isBefore(u.getCodigoGeneradoEn().plusSeconds(resendSeconds)))
            throw new ApiException(HttpStatus.TOO_MANY_REQUESTS, "Espera unos segundos antes de solicitar otro código");
        String codigo = CodigoVerificacionUtil.generarCodigo();
        u.setCodigoVerificacionHash(CodigoVerificacionUtil.hash(codigo));
        u.setCodigoGeneradoEn(LocalDateTime.now());
        u.setCodigoExpira(LocalDateTime.now().plusMinutes(expirationMinutes));
        repo.save(u);
        emailService.enviarCodigo(u.getEmail(), u.getNombre(), codigo);
        return new RegistroResponse(true, "Nuevo código enviado.", UsuarioResponse.from(u));
    }

    public AuthResponse login(LoginRequest r) {
        Usuario u = buscar(r.email());
        if (!u.isVerificada()) throw new ApiException(HttpStatus.FORBIDDEN, "Primero debes verificar tu correo");
        if (u.getEstado() == EstadoUsuario.PENDIENTE) throw new ApiException(HttpStatus.FORBIDDEN, "Tu cuenta está verificada pero PENDIENTE de aprobación del administrador");
        if (u.getEstado() == EstadoUsuario.RECHAZADA) throw new ApiException(HttpStatus.FORBIDDEN, "La cuenta fue rechazada por el administrador");
        if (u.getEstado() == EstadoUsuario.BLOQUEADA) throw new ApiException(HttpStatus.FORBIDDEN, "La cuenta está bloqueada");
        try {
            authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(u.getEmail(), r.password()));
        } catch (AuthenticationException e) {
            throw new ApiException(HttpStatus.UNAUTHORIZED, "Correo o contraseña incorrectos");
        }
        return new AuthResponse(true, "Inicio de sesión correcto", jwtService.generar(u), UsuarioResponse.from(u));
    }

    private Usuario buscar(String email) {
        return repo.findByEmailIgnoreCase(email.trim().toLowerCase())
                .orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "No existe una cuenta con ese correo"));
    }
}
