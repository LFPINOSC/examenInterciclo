package com.inventario.api.dto;

import jakarta.validation.constraints.*;

public record RegistroRequest(
    @NotBlank(message = "El nombre es obligatorio") @Size(min = 3, max = 120) String nombre,
    @NotBlank(message = "El correo es obligatorio") @Email(message = "El correo no es válido") String email,
    @NotBlank(message = "La contraseña es obligatoria")
    @Size(min = 8, max = 60, message = "La contraseña debe tener entre 8 y 60 caracteres")
    @Pattern(regexp = "^(?=.*[A-Za-z])(?=.*\\d).+$", message = "La contraseña debe contener letras y números") String password,
    @NotBlank(message = "El teléfono es obligatorio")
    @Pattern(regexp = "^[0-9+ -]{7,20}$", message = "El teléfono no tiene un formato válido") String telefono
) {}
