package com.inventario.api.service;

import com.inventario.api.exception.ApiException;
import com.inventario.api.model.Usuario;
import com.inventario.api.repository.UsuarioRepository;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

@Service
public class UsuarioActualService {
    private final UsuarioRepository repo;
    public UsuarioActualService(UsuarioRepository repo) { this.repo = repo; }

    public Usuario obtener() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null || !auth.isAuthenticated()) throw new ApiException(HttpStatus.UNAUTHORIZED, "No existe una sesión válida");
        return repo.findByEmailIgnoreCase(auth.getName())
                .orElseThrow(() -> new ApiException(HttpStatus.UNAUTHORIZED, "Usuario de la sesión no encontrado"));
    }

    public boolean esAdmin() { return obtener().getRol().name().equals("ADMIN"); }
}
