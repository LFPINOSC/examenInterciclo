package com.inventario.api.dto;

public record AuthResponse(boolean ok, String mensaje, String token, UsuarioResponse usuario) {}
