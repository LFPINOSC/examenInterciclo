package com.inventario.api.dto;

import jakarta.validation.constraints.*;

public record ReenviarCodigoRequest(@NotBlank @Email String email) {}
