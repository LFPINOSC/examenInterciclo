package com.inventario.api.repository;

import com.inventario.api.model.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;
import java.util.List;
import com.inventario.api.model.EstadoUsuario;

public interface UsuarioRepository extends JpaRepository<Usuario, Long> {
    Optional<Usuario> findByEmailIgnoreCase(String email);
    boolean existsByEmailIgnoreCase(String email);
    List<Usuario> findByEstadoOrderByCreadoEnDesc(EstadoUsuario estado);
}
