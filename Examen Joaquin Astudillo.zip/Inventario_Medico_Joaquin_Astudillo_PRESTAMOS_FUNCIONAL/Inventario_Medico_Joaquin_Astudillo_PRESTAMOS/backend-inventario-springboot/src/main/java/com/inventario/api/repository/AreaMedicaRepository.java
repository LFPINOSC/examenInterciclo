package com.inventario.api.repository;
import com.inventario.api.model.AreaMedica;
import org.springframework.data.jpa.repository.JpaRepository;
public interface AreaMedicaRepository extends JpaRepository<AreaMedica,Long> { }
