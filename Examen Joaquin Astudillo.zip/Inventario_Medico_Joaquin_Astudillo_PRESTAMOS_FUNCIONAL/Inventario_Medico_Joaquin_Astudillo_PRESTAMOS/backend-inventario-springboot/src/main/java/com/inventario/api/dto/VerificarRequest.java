package com.inventario.api.dto;

import jakarta.validation.constraints.*;

public record VerificarRequest(
    @NotBlank @Email String email,
    @NotBlank(message = "El código es obligatorio") @Pattern(regexp = "^[0-9]{6}$", message = "El código debe tener 6 dígitos") String codigo
) {}
