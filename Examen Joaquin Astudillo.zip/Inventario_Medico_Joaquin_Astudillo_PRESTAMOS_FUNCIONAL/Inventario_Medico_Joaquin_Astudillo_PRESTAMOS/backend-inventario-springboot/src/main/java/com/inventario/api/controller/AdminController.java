package com.inventario.api.controller;

import com.inventario.api.dto.*;
import com.inventario.api.exception.ResourceNotFoundException;
import com.inventario.api.model.*;
import com.inventario.api.repository.UsuarioRepository;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/admin")
public class AdminController {
    private final UsuarioRepository repo;
    public AdminController(UsuarioRepository repo) { this.repo=repo; }

    @GetMapping("/usuarios")
    public List<UsuarioResponse> usuarios() { return repo.findAll().stream().map(UsuarioResponse::from).toList(); }

    @GetMapping("/usuarios/pendientes")
    public List<UsuarioResponse> pendientes() { return repo.findByEstadoOrderByCreadoEnDesc(EstadoUsuario.PENDIENTE).stream().map(UsuarioResponse::from).toList(); }

    @PatchMapping("/usuarios/{id}/estado")
    public UsuarioResponse estado(@PathVariable Long id, @Valid @RequestBody EstadoUsuarioRequest req) {
        Usuario u=repo.findById(id).orElseThrow(() -> new ResourceNotFoundException("Usuario no encontrado: "+id));
        if (u.getRol()==Rol.ADMIN) return UsuarioResponse.from(u);
        u.setEstado(req.estado());
        return UsuarioResponse.from(repo.save(u));
    }
}
