package com.inventario.api.dto;

import com.inventario.api.model.*;

public record UsuarioResponse(Long id, String nombre, String email, String telefono, Rol rol, EstadoUsuario estado, boolean verificada) {
    public static UsuarioResponse from(Usuario u) {
        return new UsuarioResponse(u.getId(), u.getNombre(), u.getEmail(), u.getTelefono(), u.getRol(), u.getEstado(), u.isVerificada());
    }
}
