package com.inventario.api.controller;
import com.inventario.api.model.AreaMedica;
import com.inventario.api.service.AreaMedicaService;
import jakarta.validation.Valid;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController @RequestMapping("/api/areas")
public class AreaMedicaController {
 private final AreaMedicaService service;
 public AreaMedicaController(AreaMedicaService service){this.service=service;}
 @GetMapping public List<AreaMedica> listar(){return service.listar();}
 @GetMapping("/{id}") public AreaMedica buscar(@PathVariable Long id){return service.buscar(id);}
 @PostMapping public ResponseEntity<AreaMedica> crear(@Valid @RequestBody AreaMedica d){return ResponseEntity.status(HttpStatus.CREATED).body(service.crear(d));}
 @PutMapping("/{id}") public AreaMedica actualizar(@PathVariable Long id,@Valid @RequestBody AreaMedica d){return service.actualizar(id,d);}
 @DeleteMapping("/{id}") public ResponseEntity<Void> eliminar(@PathVariable Long id){service.eliminar(id);return ResponseEntity.noContent().build();}
}
