package com.inventario.api.util;

import java.nio.charset.StandardCharsets;
import java.security.*;
import java.util.HexFormat;

public final class CodigoVerificacionUtil {
    private static final SecureRandom RANDOM = new SecureRandom();
    private CodigoVerificacionUtil() {}

    public static String generarCodigo() {
        return String.format("%06d", RANDOM.nextInt(1_000_000));
    }

    public static String hash(String codigo) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            return HexFormat.of().formatHex(digest.digest(codigo.getBytes(StandardCharsets.UTF_8)));
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("SHA-256 no disponible", e);
        }
    }
}
