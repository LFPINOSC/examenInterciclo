package com.inventario.api.service;

import com.inventario.api.model.*;
import com.inventario.api.repository.*;
import com.inventario.api.exception.*;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class EquipoMedicoService {
 private final EquipoMedicoRepository repo;
 private final CategoriaRepository categorias;
 private final AreaMedicaRepository areas;
 private final UsuarioActualService sesion;
 public EquipoMedicoService(EquipoMedicoRepository repo,CategoriaRepository categorias,
       AreaMedicaRepository areas,UsuarioActualService sesion){
   this.repo=repo;this.categorias=categorias;this.areas=areas;this.sesion=sesion;
 }
 @Transactional(readOnly=true) public List<EquipoMedico> listar(){return repo.findAll();}
 @Transactional(readOnly=true) public EquipoMedico buscar(Long id){return repo.findById(id)
   .orElseThrow(()->new ResourceNotFoundException("Equipo no encontrado: "+id));}
 private EquipoMedico buscarBloqueado(Long id){return repo.buscarParaPrestamo(id)
   .orElseThrow(()->new ResourceNotFoundException("Equipo no encontrado: "+id));}
 private ApiException conflicto(String texto){return new ApiException(HttpStatus.CONFLICT,texto);}
 private void validarRelaciones(EquipoMedico e){
   Long cid=e.getCategoria()==null?null:e.getCategoria().getId();
   Long aid=e.getArea()==null?null:e.getArea().getId();
   if(cid==null||aid==null) throw new ApiException(HttpStatus.BAD_REQUEST,"Selecciona una categoría y un área válidas");
   e.setCategoria(categorias.findById(cid).orElseThrow(()->new ResourceNotFoundException("Categoría no encontrada")));
   e.setArea(areas.findById(aid).orElseThrow(()->new ResourceNotFoundException("Área no encontrada")));
   if(e.getNumeroSerie()!=null && e.getNumeroSerie().isBlank()) e.setNumeroSerie(null);
 }
 private void validarCantidad(EquipoMedico e){
   if(e.getCantidad()==null||e.getCantidad()<1) throw new ApiException(HttpStatus.BAD_REQUEST,"La cantidad debe ser mayor que cero");
 }
 @Transactional public EquipoMedico crear(EquipoMedico e){
   e.setId(null);validarRelaciones(e);validarCantidad(e);
   if(e.getEstado()==EstadoEquipo.EN_USO) throw conflicto("El estado EN USO se asigna automáticamente al solicitar un préstamo");
   // Jamás aceptar prestatarios enviados por el frontend al crear.
   e.setPrestadoPor(null);e.setPrestadoEn(null);
   return repo.save(e);
 }
 @Transactional public EquipoMedico actualizar(Long id,EquipoMedico d){
   EquipoMedico e=buscarBloqueado(id);validarRelaciones(d);validarCantidad(d);
   if(e.getPrestadoPor()!=null && d.getEstado()!=EstadoEquipo.EN_USO)
       throw conflicto("Este equipo está prestado a "+e.getPrestadoPorNombre()+". Primero se debe devolver.");
   if(e.getPrestadoPor()==null && d.getEstado()==EstadoEquipo.EN_USO)
       throw conflicto("Para marcar EN USO, un usuario debe solicitar el préstamo.");
   e.setCodigo(d.getCodigo());e.setNombre(d.getNombre());e.setMarca(d.getMarca());e.setModelo(d.getModelo());
   e.setNumeroSerie(d.getNumeroSerie());e.setCantidad(d.getCantidad());e.setFechaAdquisicion(d.getFechaAdquisicion());
   e.setEstado(d.getEstado());e.setCategoria(d.getCategoria());e.setArea(d.getArea());
   // No se permite alterar el prestatario ni la fecha por PUT.
   return repo.save(e);
 }
 @Transactional public void eliminar(Long id){
   EquipoMedico e=buscarBloqueado(id);
   if(e.getPrestadoPor()!=null) throw conflicto("No puedes eliminar un equipo prestado. Primero debe devolverse.");
   repo.delete(e);
 }
 // USER inicia el préstamo. Se registra en la tabla de equipos y se ve para TODOS.
 @Transactional public EquipoMedico solicitarPrestamo(Long id){
   EquipoMedico e=buscarBloqueado(id);
   if(e.getEstado()!=EstadoEquipo.DISPONIBLE||e.getPrestadoPor()!=null)
       throw conflicto("El equipo no está disponible para préstamo. Actualiza la lista.");
   if(e.getCantidad()==null||e.getCantidad()<1) throw conflicto("No hay existencias de este equipo");
   Usuario u=sesion.obtener();
   e.setPrestadoPor(u);e.setPrestadoEn(LocalDateTime.now());e.setEstado(EstadoEquipo.EN_USO);
   return repo.save(e);
 }
 // El propietario del préstamo o ADMIN puede registrar la devolución.
 @Transactional public EquipoMedico devolverPrestamo(Long id){
   EquipoMedico e=buscarBloqueado(id);
   if(e.getPrestadoPor()==null) throw conflicto("Este equipo no tiene un préstamo activo");
   Usuario u=sesion.obtener();
   if(!u.getId().equals(e.getPrestadoPor().getId()) && u.getRol()!=Rol.ADMIN)
       throw new ApiException(HttpStatus.FORBIDDEN,"Solo quien solicitó el equipo o el administrador puede devolverlo");
   e.setPrestadoPor(null);e.setPrestadoEn(null);e.setEstado(EstadoEquipo.DISPONIBLE);
   return repo.save(e);
 }
}
