package com.inventario.api.controller;

import org.springframework.web.bind.annotation.*;
import java.util.Map;

@RestController
public class InicioController {
    @GetMapping({"/", "/api"})
    public Map<String,Object> inicio() {
        return Map.of("aplicacion","Inventario Médico API", "estado","API funcionando", "backend","Spring Boot + Java 21", "frontend","Angular");
    }
}
