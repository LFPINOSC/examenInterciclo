package com.inventario.api.model;
public enum EstadoEquipo { DISPONIBLE, EN_USO, FUERA_DE_SERVICIO }
