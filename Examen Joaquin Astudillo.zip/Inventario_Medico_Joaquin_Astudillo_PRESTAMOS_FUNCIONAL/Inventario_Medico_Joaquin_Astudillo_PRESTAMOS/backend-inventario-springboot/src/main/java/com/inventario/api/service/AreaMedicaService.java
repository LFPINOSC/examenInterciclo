package com.inventario.api.service;
import com.inventario.api.exception.*;
import com.inventario.api.model.AreaMedica;
import com.inventario.api.repository.AreaMedicaRepository;
import com.inventario.api.repository.EquipoMedicoRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import java.util.List;
@Service
public class AreaMedicaService {
 private final AreaMedicaRepository repo;
 private final EquipoMedicoRepository equipos;
 public AreaMedicaService(AreaMedicaRepository repo,EquipoMedicoRepository equipos){this.repo=repo;this.equipos=equipos;}
 public List<AreaMedica> listar(){return repo.findAll();}
 public AreaMedica buscar(Long id){return repo.findById(id).orElseThrow(()->new ResourceNotFoundException("Área médica no encontrada: "+id));}
 public AreaMedica crear(AreaMedica datos){datos.setId(null);return repo.save(datos);}
 public AreaMedica actualizar(Long id,AreaMedica datos){AreaMedica actual=buscar(id);actual.setNombre(datos.getNombre()); actual.setResponsable(datos.getResponsable()); actual.setDescripcion(datos.getDescripcion()); return repo.save(actual);}
 public void eliminar(Long id){buscar(id);if(equipos.existsByArea_Id(id)) throw new ApiException(HttpStatus.CONFLICT,"No se puede eliminar: tiene equipos asociados");repo.deleteById(id);}
}
