package com.inventario.api.dto;

import com.inventario.api.model.EstadoUsuario;
import jakarta.validation.constraints.NotNull;

public record EstadoUsuarioRequest(@NotNull(message = "El estado es obligatorio") EstadoUsuario estado) {}
