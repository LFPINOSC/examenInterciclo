package com.inventario.api.model;

public enum Rol { USER, ADMIN }
