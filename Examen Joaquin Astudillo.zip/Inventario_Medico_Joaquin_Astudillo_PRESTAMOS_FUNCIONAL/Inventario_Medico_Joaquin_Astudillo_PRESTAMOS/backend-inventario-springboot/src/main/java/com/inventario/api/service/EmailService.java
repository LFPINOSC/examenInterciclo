package com.inventario.api.service;

import com.inventario.api.exception.ApiException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
public class EmailService {
    private final JavaMailSender mailSender;

    @Value("${spring.mail.username:}")
    private String remitente;

    @Value("${spring.mail.password:}")
    private String passwordAplicacion;

    public EmailService(JavaMailSender mailSender) {
        this.mailSender = mailSender;
    }

    // Gmail REAL por SMTP. No existe modo de simulacion ni devolucion de codigos al cliente.
    public void enviarCodigo(String destino, String nombre, String codigo) {
        if (remitente == null || remitente.isBlank() ||
                passwordAplicacion == null || passwordAplicacion.isBlank()) {
            throw new ApiException(HttpStatus.BAD_GATEWAY,
                "Gmail no esta configurado. Define GMAIL_USER y GMAIL_APP_PASSWORD antes de ejecutar Spring Boot.");
        }

        SimpleMailMessage mensaje = new SimpleMailMessage();
        mensaje.setFrom(remitente);
        mensaje.setTo(destino);
        mensaje.setSubject("Codigo de verificacion - Inventario de Equipos Medicos");
        mensaje.setText("Hola " + nombre + ",\n\n" +
                "Tu codigo de verificacion es: " + codigo + "\n\n" +
                "Este codigo vence en 10 minutos.\n" +
                "Si no solicitaste una cuenta, ignora este mensaje.\n\n" +
                "Inventario de Equipos Medicos");
        mailSender.send(mensaje);
    }
}
