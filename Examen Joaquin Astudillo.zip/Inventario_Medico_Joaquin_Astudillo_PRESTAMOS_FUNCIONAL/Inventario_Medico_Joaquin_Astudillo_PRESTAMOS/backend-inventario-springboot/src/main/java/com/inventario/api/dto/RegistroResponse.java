package com.inventario.api.dto;

public record RegistroResponse(boolean ok, String mensaje, UsuarioResponse usuario) {}
