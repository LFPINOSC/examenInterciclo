package com.inventario.api.exception;

import org.springframework.http.*;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.mail.MailException;
import org.springframework.security.access.AccessDeniedException;
import java.util.*;

@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(ApiException.class)
    public ResponseEntity<Map<String,Object>> api(ApiException ex) {
        return ResponseEntity.status(ex.getStatus()).body(body(ex.getStatus().value(), ex.getMessage(), null));
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<Map<String,Object>> validation(MethodArgumentNotValidException ex) {
        Map<String,String> errors = new LinkedHashMap<>();
        ex.getBindingResult().getFieldErrors().forEach(e -> errors.put(e.getField(), e.getDefaultMessage()));
        return ResponseEntity.badRequest().body(body(400, "Revisa los datos enviados", errors));
    }

    @ExceptionHandler(DataIntegrityViolationException.class)
    public ResponseEntity<Map<String,Object>> integrity(DataIntegrityViolationException ex) {
        return ResponseEntity.status(HttpStatus.CONFLICT).body(body(409, "Existe un conflicto con los datos almacenados", null));
    }

    @ExceptionHandler(MailException.class)
    public ResponseEntity<Map<String,Object>> mail(MailException ex) {
        ex.printStackTrace();
        return ResponseEntity.status(HttpStatus.BAD_GATEWAY)
            .body(body(502, "No se pudo enviar el correo real. Revisa Gmail, la contraseña de aplicación y la conexión SMTP.", null));
    }

    @ExceptionHandler(AccessDeniedException.class)
    public ResponseEntity<Map<String,Object>> denied(AccessDeniedException ex) {
        return ResponseEntity.status(HttpStatus.FORBIDDEN).body(body(403, "No tienes permisos para realizar esta operación", null));
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<Map<String,Object>> other(Exception ex) {
        ex.printStackTrace();
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(body(500, "Error interno del servidor", null));
    }

    private Map<String,Object> body(int status, String mensaje, Object validationErrors) {
        Map<String,Object> m = new LinkedHashMap<>();
        m.put("ok", false);
        m.put("status", status);
        m.put("mensaje", mensaje);
        if (validationErrors != null) m.put("validationErrors", validationErrors);
        return m;
    }
}
