package com.inventario.api.repository;
import com.inventario.api.model.EquipoMedico;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import jakarta.persistence.LockModeType;
import java.util.Optional;
public interface EquipoMedicoRepository extends JpaRepository<EquipoMedico,Long> {
 @Lock(LockModeType.PESSIMISTIC_WRITE)
 @Query("select e from EquipoMedico e where e.id=:id")
 Optional<EquipoMedico> buscarParaPrestamo(@Param("id") Long id);
 boolean existsByCategoria_Id(Long id);
 boolean existsByArea_Id(Long id);
}
