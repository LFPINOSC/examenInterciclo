package com.inventario.api.controller;
import com.inventario.api.model.EquipoMedico;
import com.inventario.api.service.EquipoMedicoService;
import jakarta.validation.Valid;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController @RequestMapping("/api/equipos")
public class EquipoMedicoController {
 private final EquipoMedicoService service;
 public EquipoMedicoController(EquipoMedicoService service){this.service=service;}
 @GetMapping public List<EquipoMedico> listar(){return service.listar();}
 @GetMapping("/{id}") public EquipoMedico buscar(@PathVariable Long id){return service.buscar(id);}
 @PostMapping public ResponseEntity<EquipoMedico> crear(@Valid @RequestBody EquipoMedico d){return ResponseEntity.status(HttpStatus.CREATED).body(service.crear(d));}
 @PutMapping("/{id}") public EquipoMedico actualizar(@PathVariable Long id,@Valid @RequestBody EquipoMedico d){return service.actualizar(id,d);}
 @PostMapping("/{id}/prestar") public EquipoMedico solicitarPrestamo(@PathVariable Long id){return service.solicitarPrestamo(id);}
 @PostMapping("/{id}/devolver") public EquipoMedico devolverPrestamo(@PathVariable Long id){return service.devolverPrestamo(id);}
 @DeleteMapping("/{id}") public ResponseEntity<Void> eliminar(@PathVariable Long id){service.eliminar(id);return ResponseEntity.noContent().build();}
}
