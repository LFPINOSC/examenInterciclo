package com.inventario.api.model;

public enum EstadoUsuario { PENDIENTE, APROBADA, RECHAZADA, BLOQUEADA }
