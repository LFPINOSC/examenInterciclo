package com.inventario.api.config;
import com.inventario.api.model.*;
import com.inventario.api.repository.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.*;
import org.springframework.security.crypto.password.PasswordEncoder;
@Configuration
public class DatosInicialesConfig {
 @Bean CommandLineRunner datosIniciales(UsuarioRepository usuarios,CategoriaRepository categorias,AreaMedicaRepository areas,EquipoMedicoRepository equipos,PasswordEncoder encoder,
  @Value("${app.admin.name}") String adminName,@Value("${app.admin.email}") String adminEmail,@Value("${app.admin.password}") String adminPassword){
  return args->{
   Usuario admin=usuarios.findByEmailIgnoreCase(adminEmail).orElseGet(Usuario::new);
   admin.setNombre(adminName);admin.setEmail(adminEmail.toLowerCase());
   if(admin.getId()==null || !encoder.matches(adminPassword,admin.getPasswordHash())) admin.setPasswordHash(encoder.encode(adminPassword));
   admin.setRol(Rol.ADMIN);admin.setEstado(EstadoUsuario.APROBADA);admin.setVerificada(true);admin.setTelefono("0990000000");usuarios.save(admin);
   if(categorias.count()==0){
     Categoria c=new Categoria();c.setNombre("Diagnóstico");c.setDescripcion("Equipos de evaluación clínica");categorias.save(c);
     Categoria m=new Categoria();m.setNombre("Monitoreo");m.setDescripcion("Control de signos vitales");categorias.save(m);
   }
   if(areas.count()==0){
     AreaMedica a=new AreaMedica();a.setNombre("Emergencias");a.setResponsable("Jefatura de emergencias");areas.save(a);
     AreaMedica q=new AreaMedica();q.setNombre("Consultorio 1");q.setResponsable("Personal médico");areas.save(q);
   }
   if(equipos.count()==0){
     EquipoMedico e=new EquipoMedico();e.setCodigo("EQ-001");e.setNombre("Monitor multiparámetro");e.setMarca("Mindray");e.setModelo("uMEC10");
     e.setNumeroSerie("INV-0001");e.setCantidad(1);e.setEstado(EstadoEquipo.DISPONIBLE);
     e.setCategoria(categorias.findAll().get(0));e.setArea(areas.findAll().get(0));equipos.save(e);
   }
  };
 }
}
