-- GYM CONTROL: 4 tablas (Usuario, Membresia, Socio, Pago)
-- Ejecutar en MySQL Workbench SOLO si deseas instalar la estructura con SQL.
-- El backend tambien puede crear/actualizar las tablas al arrancar (JPA ddl-auto=update).
CREATE DATABASE IF NOT EXISTS gym_control CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE gym_control;

CREATE TABLE IF NOT EXISTS usuarios (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(100) NOT NULL,
  username VARCHAR(50) NOT NULL UNIQUE,
  password_hash VARCHAR(100) NOT NULL,
  rol VARCHAR(16) NOT NULL,
  activo BOOLEAN NOT NULL DEFAULT TRUE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS membresias (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(90) NOT NULL UNIQUE,
  descripcion VARCHAR(300) NULL,
  duracion_dias INT NOT NULL,
  precio DECIMAL(10,2) NOT NULL,
  activa BOOLEAN NOT NULL DEFAULT TRUE,
  CONSTRAINT ck_membresia_duracion CHECK(duracion_dias > 0),
  CONSTRAINT ck_membresia_precio CHECK(precio > 0)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS socios (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  nombres VARCHAR(90) NOT NULL,
  apellidos VARCHAR(90) NOT NULL,
  cedula VARCHAR(15) NOT NULL UNIQUE,
  telefono VARCHAR(20) NULL,
  fecha_ingreso DATE NOT NULL,
  activo BOOLEAN NOT NULL DEFAULT TRUE,
  membresia_id BIGINT NOT NULL,
  CONSTRAINT fk_socio_membresia FOREIGN KEY(membresia_id) REFERENCES membresias(id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS pagos (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  socio_id BIGINT NOT NULL,
  fecha_pago DATE NOT NULL,
  monto DECIMAL(10,2) NOT NULL,
  metodo_pago VARCHAR(20) NOT NULL,
  observacion VARCHAR(250) NULL,
  CONSTRAINT fk_pago_socio FOREIGN KEY(socio_id) REFERENCES socios(id),
  CONSTRAINT ck_pago_monto CHECK(monto > 0)
) ENGINE=InnoDB;
