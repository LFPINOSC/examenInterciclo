USE gym_control;
SHOW TABLES;
SELECT id, nombre, username, rol, activo FROM usuarios;
SELECT id, nombre, duracion_dias, precio, activa FROM membresias;
SELECT s.id, s.nombres, s.apellidos, s.cedula, m.nombre AS plan FROM socios s JOIN membresias m ON m.id=s.membresia_id;
SELECT p.id, CONCAT(s.nombres,' ',s.apellidos) AS socio, p.fecha_pago, p.monto, p.metodo_pago FROM pagos p JOIN socios s ON p.socio_id=s.id;
