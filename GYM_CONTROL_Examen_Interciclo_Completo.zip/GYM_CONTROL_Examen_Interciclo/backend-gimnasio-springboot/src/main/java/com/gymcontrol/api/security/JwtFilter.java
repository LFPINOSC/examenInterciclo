package com.gymcontrol.api.security;
import com.gymcontrol.api.model.Usuario;
import com.gymcontrol.api.repository.UsuarioRepository;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import java.io.IOException;
import java.util.List;
@Component
public class JwtFilter extends OncePerRequestFilter {
 private final JwtService jwt; private final UsuarioRepository usuarios;
 public JwtFilter(JwtService jwt,UsuarioRepository usuarios){this.jwt=jwt;this.usuarios=usuarios;}
 @Override protected void doFilterInternal(HttpServletRequest req,HttpServletResponse res,FilterChain chain) throws IOException,ServletException {
  String h=req.getHeader("Authorization");
  if(h!=null && h.startsWith("Bearer ") && SecurityContextHolder.getContext().getAuthentication()==null){
   try { String username=jwt.username(h.substring(7));
    Usuario u=usuarios.findByUsernameIgnoreCase(username).orElse(null);
    if(u!=null && u.activo){SecurityContextHolder.getContext().setAuthentication(new UsernamePasswordAuthenticationToken(u.username,null,List.of(new SimpleGrantedAuthority("ROLE_"+u.rol.name()))));}
   }catch(Exception ignored){}
  }
  chain.doFilter(req,res);
 }
}
