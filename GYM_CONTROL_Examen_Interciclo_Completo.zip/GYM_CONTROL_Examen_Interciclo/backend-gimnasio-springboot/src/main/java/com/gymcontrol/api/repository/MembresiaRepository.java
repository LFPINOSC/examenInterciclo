package com.gymcontrol.api.repository;
import com.gymcontrol.api.model.Membresia;
import org.springframework.data.jpa.repository.JpaRepository;
public interface MembresiaRepository extends JpaRepository<Membresia,Long> {
 boolean existsByNombreIgnoreCase(String nombre);
}
