package com.gymcontrol.api.model;
import jakarta.persistence.*;
import java.math.BigDecimal;
@Entity @Table(name="membresias")
public class Membresia {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) public Long id;
 @Column(nullable=false,unique=true,length=90) public String nombre;
 @Column(length=300) public String descripcion;
 @Column(name="duracion_dias",nullable=false) public Integer duracionDias;
 @Column(nullable=false,precision=10,scale=2) public BigDecimal precio;
 @Column(nullable=false) public boolean activa=true;
}
