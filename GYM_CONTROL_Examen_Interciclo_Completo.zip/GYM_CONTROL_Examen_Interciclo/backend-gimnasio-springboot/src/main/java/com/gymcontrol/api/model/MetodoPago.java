package com.gymcontrol.api.model;
public enum MetodoPago { EFECTIVO, TRANSFERENCIA, TARJETA }
