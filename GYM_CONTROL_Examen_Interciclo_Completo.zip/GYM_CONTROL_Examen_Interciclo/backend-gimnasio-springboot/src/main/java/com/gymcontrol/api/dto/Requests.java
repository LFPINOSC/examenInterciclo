package com.gymcontrol.api.dto;
import com.gymcontrol.api.model.*;
import jakarta.validation.constraints.*;
import java.math.BigDecimal;
import java.time.LocalDate;
public final class Requests {
 private Requests(){}
 public record Login(@NotBlank String username, @NotBlank String password) {}
 public record UsuarioForm(@NotBlank String nombre,@NotBlank String username,String password,@NotNull Rol rol,boolean activo) {}
 public record MembresiaForm(@NotBlank String nombre,String descripcion,@NotNull @Min(1) Integer duracionDias,@NotNull @DecimalMin("0.01") BigDecimal precio,boolean activa) {}
 public record SocioForm(@NotBlank String nombres,@NotBlank String apellidos,@NotBlank String cedula,String telefono,@NotNull LocalDate fechaIngreso,boolean activo,@NotNull Long membresiaId) {}
 public record PagoForm(@NotNull Long socioId,@NotNull LocalDate fechaPago,@NotNull @DecimalMin("0.01") BigDecimal monto,@NotNull MetodoPago metodoPago,String observacion) {}
}
