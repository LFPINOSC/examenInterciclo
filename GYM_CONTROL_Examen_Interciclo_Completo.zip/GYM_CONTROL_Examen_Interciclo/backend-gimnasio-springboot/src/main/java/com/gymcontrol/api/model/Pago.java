package com.gymcontrol.api.model;
import jakarta.persistence.*;
import java.time.LocalDate;
import java.math.BigDecimal;
@Entity @Table(name="pagos")
public class Pago {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) public Long id;
 @ManyToOne(optional=false,fetch=FetchType.EAGER) @JoinColumn(name="socio_id",nullable=false) public Socio socio;
 @Column(name="fecha_pago",nullable=false) public LocalDate fechaPago=LocalDate.now();
 @Column(nullable=false,precision=10,scale=2) public BigDecimal monto;
 @Enumerated(EnumType.STRING) @Column(name="metodo_pago",nullable=false,length=20) public MetodoPago metodoPago;
 @Column(length=250) public String observacion;
}
