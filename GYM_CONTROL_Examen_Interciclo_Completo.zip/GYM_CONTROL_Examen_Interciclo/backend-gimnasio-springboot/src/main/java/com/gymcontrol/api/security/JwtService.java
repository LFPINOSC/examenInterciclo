package com.gymcontrol.api.security;
import com.gymcontrol.api.model.Usuario;
import io.jsonwebtoken.*;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.util.Date;
@Service
public class JwtService {
 @Value("${app.jwt.secret}") private String secret;
 @Value("${app.jwt.expiration-ms}") private long expiration;
 private SecretKey key(){return Keys.hmacShaKeyFor(secret.getBytes(StandardCharsets.UTF_8));}
 public String generar(Usuario u){long ahora=System.currentTimeMillis();return Jwts.builder().subject(u.username).claim("rol",u.rol.name()).issuedAt(new Date(ahora)).expiration(new Date(ahora+expiration)).signWith(key()).compact();}
 public String username(String jwt){return Jwts.parser().verifyWith(key()).build().parseSignedClaims(jwt).getPayload().getSubject();}
}
