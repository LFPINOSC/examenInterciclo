package com.gymcontrol.api.controller;
import com.gymcontrol.api.dto.Requests;
import com.gymcontrol.api.model.*;
import com.gymcontrol.api.repository.*;
import com.gymcontrol.api.exception.ApiException;
import jakarta.validation.Valid;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.util.*;
@RestController @RequestMapping("/api/pagos")
public class PagoController {
 private final PagoRepository repo;private final SocioRepository socios;
 public PagoController(PagoRepository repo,SocioRepository socios){this.repo=repo;this.socios=socios;}
 @GetMapping public List<Pago> listar(){return repo.findAll();}
 @GetMapping("/{id}") public Pago uno(@PathVariable Long id){return buscar(id);}
 @PostMapping @ResponseStatus(HttpStatus.CREATED) public Pago crear(@Valid @RequestBody Requests.PagoForm f){Pago p=new Pago();copiar(p,f);return repo.save(p);}
 @PutMapping("/{id}") public Pago editar(@PathVariable Long id,@Valid @RequestBody Requests.PagoForm f){Pago p=buscar(id);copiar(p,f);return repo.save(p);}
 @DeleteMapping("/{id}") @ResponseStatus(HttpStatus.NO_CONTENT) public void eliminar(@PathVariable Long id){repo.delete(buscar(id));}
 private Pago buscar(Long id){return repo.findById(id).orElseThrow(()->new ApiException(HttpStatus.NOT_FOUND,"Pago no encontrado"));}
 private void copiar(Pago p,Requests.PagoForm f){p.socio=socios.findById(f.socioId()).orElseThrow(()->new ApiException(HttpStatus.BAD_REQUEST,"Socio no existe"));p.fechaPago=f.fechaPago();p.monto=f.monto();p.metodoPago=f.metodoPago();p.observacion=f.observacion();}
}
