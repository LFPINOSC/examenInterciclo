package com.gymcontrol.api.controller;
import com.gymcontrol.api.dto.Requests;
import com.gymcontrol.api.model.*;
import com.gymcontrol.api.repository.*;
import com.gymcontrol.api.exception.ApiException;
import jakarta.validation.Valid;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.util.*;
@RestController @RequestMapping("/api/socios")
public class SocioController {
 private final SocioRepository repo;private final MembresiaRepository membresias;private final PagoRepository pagos;
 public SocioController(SocioRepository repo,MembresiaRepository membresias,PagoRepository pagos){this.repo=repo;this.membresias=membresias;this.pagos=pagos;}
 @GetMapping public List<Socio> listar(){return repo.findAll();}
 @GetMapping("/{id}") public Socio uno(@PathVariable Long id){return buscar(id);}
 @PostMapping @ResponseStatus(HttpStatus.CREATED) public Socio crear(@Valid @RequestBody Requests.SocioForm f){
  if(repo.existsByCedula(f.cedula().trim()))throw new ApiException(HttpStatus.CONFLICT,"Ya existe un socio con esa cedula");
  Socio s=new Socio();copiar(s,f);return repo.save(s);
 }
 @PutMapping("/{id}") public Socio editar(@PathVariable Long id,@Valid @RequestBody Requests.SocioForm f){Socio s=buscar(id);
  if(!s.cedula.equals(f.cedula().trim())&&repo.existsByCedula(f.cedula().trim()))throw new ApiException(HttpStatus.CONFLICT,"Ya existe un socio con esa cedula");
  copiar(s,f);return repo.save(s);
 }
 @DeleteMapping("/{id}") @ResponseStatus(HttpStatus.NO_CONTENT) public void eliminar(@PathVariable Long id){Socio s=buscar(id);
  if(pagos.existsBySocioId(id))throw new ApiException(HttpStatus.CONFLICT,"Este socio tiene pagos. Elimina primero sus pagos o desactiva al socio");repo.delete(s);
 }
 private Socio buscar(Long id){return repo.findById(id).orElseThrow(()->new ApiException(HttpStatus.NOT_FOUND,"Socio no encontrado"));}
 private void copiar(Socio s,Requests.SocioForm f){s.nombres=f.nombres().trim();s.apellidos=f.apellidos().trim();s.cedula=f.cedula().trim();s.telefono=f.telefono();s.fechaIngreso=f.fechaIngreso();s.activo=f.activo();s.membresia=membresias.findById(f.membresiaId()).orElseThrow(()->new ApiException(HttpStatus.BAD_REQUEST,"Membresia no existe"));}
}
