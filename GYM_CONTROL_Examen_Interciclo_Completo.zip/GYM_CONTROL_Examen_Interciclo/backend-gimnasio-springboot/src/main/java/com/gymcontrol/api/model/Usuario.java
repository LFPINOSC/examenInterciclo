package com.gymcontrol.api.model;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
@Entity @Table(name="usuarios", uniqueConstraints=@UniqueConstraint(columnNames="username"))
public class Usuario {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) public Long id;
 @Column(nullable=false,length=100) public String nombre;
 @Column(nullable=false,length=50) public String username;
 @JsonIgnore @Column(name="password_hash",nullable=false,length=100) public String passwordHash;
 @Enumerated(EnumType.STRING) @Column(nullable=false,length=16) public Rol rol=Rol.OPERADOR;
 @Column(nullable=false) public boolean activo=true;
}
