package com.gymcontrol.api.controller;
import com.gymcontrol.api.dto.Requests;
import com.gymcontrol.api.model.Membresia;
import com.gymcontrol.api.repository.*;
import com.gymcontrol.api.exception.ApiException;
import jakarta.validation.Valid;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.util.*;
@RestController @RequestMapping("/api/membresias")
public class MembresiaController {
 private final MembresiaRepository repo;private final SocioRepository socios;
 public MembresiaController(MembresiaRepository repo,SocioRepository socios){this.repo=repo;this.socios=socios;}
 @GetMapping public List<Membresia> listar(){return repo.findAll();}
 @GetMapping("/{id}") public Membresia uno(@PathVariable Long id){return buscar(id);}
 @PostMapping @ResponseStatus(HttpStatus.CREATED) public Membresia crear(@Valid @RequestBody Requests.MembresiaForm f){
  if(repo.existsByNombreIgnoreCase(f.nombre().trim()))throw new ApiException(HttpStatus.CONFLICT,"Ya existe una membresia con ese nombre");
  Membresia m=new Membresia();copiar(m,f);return repo.save(m);
 }
 @PutMapping("/{id}") public Membresia editar(@PathVariable Long id,@Valid @RequestBody Requests.MembresiaForm f){Membresia m=buscar(id);
  if(!m.nombre.equalsIgnoreCase(f.nombre().trim())&&repo.existsByNombreIgnoreCase(f.nombre().trim()))throw new ApiException(HttpStatus.CONFLICT,"Ya existe una membresia con ese nombre");
  copiar(m,f);return repo.save(m);
 }
 @DeleteMapping("/{id}") @ResponseStatus(HttpStatus.NO_CONTENT) public void eliminar(@PathVariable Long id){Membresia m=buscar(id);
  if(socios.existsByMembresiaId(id))throw new ApiException(HttpStatus.CONFLICT,"No puedes eliminar una membresia asignada a socios");repo.delete(m);
 }
 private Membresia buscar(Long id){return repo.findById(id).orElseThrow(()->new ApiException(HttpStatus.NOT_FOUND,"Membresia no encontrada"));}
 private void copiar(Membresia m,Requests.MembresiaForm f){m.nombre=f.nombre().trim();m.descripcion=f.descripcion();m.duracionDias=f.duracionDias();m.precio=f.precio();m.activa=f.activa();}
}
