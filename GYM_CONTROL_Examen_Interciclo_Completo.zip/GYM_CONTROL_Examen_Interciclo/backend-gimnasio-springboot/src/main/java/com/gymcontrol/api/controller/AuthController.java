package com.gymcontrol.api.controller;
import com.gymcontrol.api.dto.Requests;
import com.gymcontrol.api.model.Usuario;
import com.gymcontrol.api.repository.UsuarioRepository;
import com.gymcontrol.api.security.JwtService;
import com.gymcontrol.api.exception.ApiException;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;
import java.util.Map;
@RestController @RequestMapping("/api/auth")
public class AuthController {
 private final UsuarioRepository usuarios;private final PasswordEncoder encoder;private final JwtService jwt;
 public AuthController(UsuarioRepository usuarios,PasswordEncoder encoder,JwtService jwt){this.usuarios=usuarios;this.encoder=encoder;this.jwt=jwt;}
 @PostMapping("/login") public Map<String,Object> login(@Valid @RequestBody Requests.Login r){
  Usuario u=usuarios.findByUsernameIgnoreCase(r.username().trim()).orElseThrow(()->new ApiException(HttpStatus.UNAUTHORIZED,"Usuario o clave incorrectos"));
  if(!u.activo||!encoder.matches(r.password(),u.passwordHash))throw new ApiException(HttpStatus.UNAUTHORIZED,"Usuario o clave incorrectos");
  return Map.of("token",jwt.generar(u),"usuario",u);
 }
 @GetMapping("/perfil") public Usuario perfil(Authentication auth){return usuarios.findByUsernameIgnoreCase(auth.getName()).orElseThrow();}
}
