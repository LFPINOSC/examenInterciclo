package com.gymcontrol.api.repository;
import com.gymcontrol.api.model.Pago;
import org.springframework.data.jpa.repository.JpaRepository;
public interface PagoRepository extends JpaRepository<Pago,Long> {
 boolean existsBySocioId(Long id);
}
