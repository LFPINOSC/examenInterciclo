package com.gymcontrol.api.exception;
import org.springframework.http.*;
import org.springframework.web.bind.*;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.annotation.*;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.security.access.AccessDeniedException;
import java.util.*;
@RestControllerAdvice
public class ErrorHandler {
 @ExceptionHandler(ApiException.class) ResponseEntity<?> api(ApiException e){return ResponseEntity.status(e.status).body(Map.of("mensaje",e.getMessage()));}
 @ExceptionHandler(MethodArgumentNotValidException.class) ResponseEntity<?> valid(MethodArgumentNotValidException e){
  Map<String,String> campos=new LinkedHashMap<>();e.getBindingResult().getFieldErrors().forEach(x->campos.put(x.getField(),x.getDefaultMessage()));
  return ResponseEntity.badRequest().body(Map.of("mensaje","Revisa los campos del formulario","campos",campos));
 }
 @ExceptionHandler(DataIntegrityViolationException.class) ResponseEntity<?> integrity(DataIntegrityViolationException e){return ResponseEntity.status(409).body(Map.of("mensaje","El registro esta relacionado con otros datos o hay un valor duplicado"));}
 @ExceptionHandler(AccessDeniedException.class) ResponseEntity<?> denied(AccessDeniedException e){return ResponseEntity.status(403).body(Map.of("mensaje","No tienes permisos para esta accion"));}
 @ExceptionHandler(HttpMessageNotReadableException.class) ResponseEntity<?> malformed(HttpMessageNotReadableException e){return ResponseEntity.badRequest().body(Map.of("mensaje","Los datos enviados no tienen el formato correcto"));}
}
