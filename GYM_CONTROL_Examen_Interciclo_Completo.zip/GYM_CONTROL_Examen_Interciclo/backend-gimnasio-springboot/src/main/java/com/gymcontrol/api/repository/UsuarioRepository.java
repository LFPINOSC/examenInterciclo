package com.gymcontrol.api.repository;
import com.gymcontrol.api.model.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
public interface UsuarioRepository extends JpaRepository<Usuario,Long> {
 boolean existsByUsernameIgnoreCase(String username);
 java.util.Optional<Usuario> findByUsernameIgnoreCase(String username);
 long countByRolAndActivoTrue(com.gymcontrol.api.model.Rol rol);
}
