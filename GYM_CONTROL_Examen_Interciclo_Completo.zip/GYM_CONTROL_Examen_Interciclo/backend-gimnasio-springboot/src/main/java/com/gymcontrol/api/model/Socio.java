package com.gymcontrol.api.model;
import jakarta.persistence.*;
import java.time.LocalDate;
@Entity @Table(name="socios",uniqueConstraints=@UniqueConstraint(columnNames="cedula"))
public class Socio {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) public Long id;
 @Column(nullable=false,length=90) public String nombres;
 @Column(nullable=false,length=90) public String apellidos;
 @Column(nullable=false,length=15) public String cedula;
 @Column(length=20) public String telefono;
 @Column(name="fecha_ingreso",nullable=false) public LocalDate fechaIngreso=LocalDate.now();
 @Column(nullable=false) public boolean activo=true;
 @ManyToOne(optional=false,fetch=FetchType.EAGER) @JoinColumn(name="membresia_id",nullable=false) public Membresia membresia;
}
