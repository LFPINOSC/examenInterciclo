package com.gymcontrol.api.controller;
import com.gymcontrol.api.dto.Requests;
import com.gymcontrol.api.model.*;
import com.gymcontrol.api.repository.UsuarioRepository;
import com.gymcontrol.api.exception.ApiException;
import jakarta.validation.Valid;
import org.springframework.http.*;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;
import java.util.*;
@RestController @RequestMapping("/api/usuarios")
public class UsuarioController {
 private final UsuarioRepository repo;private final PasswordEncoder encoder;
 public UsuarioController(UsuarioRepository repo,PasswordEncoder encoder){this.repo=repo;this.encoder=encoder;}
 @GetMapping public List<Usuario> listar(){return repo.findAll();}
 @GetMapping("/{id}") public Usuario uno(@PathVariable Long id){return buscar(id);}
 @PostMapping @ResponseStatus(HttpStatus.CREATED) public Usuario crear(@Valid @RequestBody Requests.UsuarioForm f){
  if(f.password()==null||f.password().length()<8)throw new ApiException(HttpStatus.BAD_REQUEST,"La clave debe tener al menos 8 caracteres");
  if(repo.existsByUsernameIgnoreCase(f.username().trim()))throw new ApiException(HttpStatus.CONFLICT,"Nombre de usuario ya registrado");
  Usuario u=new Usuario();copiar(u,f);u.passwordHash=encoder.encode(f.password());return repo.save(u);
 }
 @PutMapping("/{id}") public Usuario editar(@PathVariable Long id,@Valid @RequestBody Requests.UsuarioForm f,Authentication auth){
  Usuario u=buscar(id);if(!u.username.equalsIgnoreCase(f.username().trim())&&repo.existsByUsernameIgnoreCase(f.username().trim()))throw new ApiException(HttpStatus.CONFLICT,"Nombre de usuario ya registrado");
  if(u.username.equalsIgnoreCase(auth.getName())&&(!f.activo()||f.rol()!=Rol.ADMIN))throw new ApiException(HttpStatus.BAD_REQUEST,"No puedes desactivar o quitarte tu rol de administrador");
  if(u.rol==Rol.ADMIN&&(f.rol()!=Rol.ADMIN||!f.activo())&&repo.countByRolAndActivoTrue(Rol.ADMIN)<=1)throw new ApiException(HttpStatus.BAD_REQUEST,"Debe existir al menos un administrador activo");
  copiar(u,f);if(f.password()!=null&&!f.password().isBlank()){if(f.password().length()<8)throw new ApiException(HttpStatus.BAD_REQUEST,"La nueva clave requiere 8 caracteres");u.passwordHash=encoder.encode(f.password());}
  return repo.save(u);
 }
 @DeleteMapping("/{id}") @ResponseStatus(HttpStatus.NO_CONTENT) public void eliminar(@PathVariable Long id,Authentication auth){Usuario u=buscar(id);
  if(u.username.equalsIgnoreCase(auth.getName()))throw new ApiException(HttpStatus.BAD_REQUEST,"No puedes eliminar tu propia cuenta");
  if(u.rol==Rol.ADMIN&&u.activo&&repo.countByRolAndActivoTrue(Rol.ADMIN)<=1)throw new ApiException(HttpStatus.BAD_REQUEST,"Debe existir un administrador activo");
  repo.delete(u);
 }
 private Usuario buscar(Long id){return repo.findById(id).orElseThrow(()->new ApiException(HttpStatus.NOT_FOUND,"Usuario no encontrado"));}
 private void copiar(Usuario u,Requests.UsuarioForm f){u.nombre=f.nombre().trim();u.username=f.username().trim().toLowerCase();u.rol=f.rol();u.activo=f.activo();}
}
