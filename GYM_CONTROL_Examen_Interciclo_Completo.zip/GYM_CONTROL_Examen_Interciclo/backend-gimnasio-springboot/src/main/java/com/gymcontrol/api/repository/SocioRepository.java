package com.gymcontrol.api.repository;
import com.gymcontrol.api.model.Socio;
import org.springframework.data.jpa.repository.JpaRepository;
public interface SocioRepository extends JpaRepository<Socio,Long> {
 boolean existsByCedula(String cedula);
 boolean existsByMembresiaId(Long id);
}
