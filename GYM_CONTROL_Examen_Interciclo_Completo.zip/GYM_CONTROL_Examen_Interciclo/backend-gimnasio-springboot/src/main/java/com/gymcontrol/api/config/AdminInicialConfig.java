package com.gymcontrol.api.config;
import com.gymcontrol.api.model.*;
import com.gymcontrol.api.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.*;
import org.springframework.security.crypto.password.PasswordEncoder;
@Configuration
public class AdminInicialConfig {
 @Bean CommandLineRunner usuarioInicial(UsuarioRepository repo,PasswordEncoder encoder,
  @Value("${app.admin.username}") String username,@Value("${app.admin.password}") String password,@Value("${app.admin.name}") String nombre){
  return args->{if(repo.count()==0){Usuario u=new Usuario();u.username=username;u.nombre=nombre;u.passwordHash=encoder.encode(password);u.rol=Rol.ADMIN;u.activo=true;repo.save(u);}};
 }
}
