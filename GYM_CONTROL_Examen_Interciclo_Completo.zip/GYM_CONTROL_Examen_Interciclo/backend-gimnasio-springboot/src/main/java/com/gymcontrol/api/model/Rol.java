package com.gymcontrol.api.model;
public enum Rol { ADMIN, OPERADOR }
