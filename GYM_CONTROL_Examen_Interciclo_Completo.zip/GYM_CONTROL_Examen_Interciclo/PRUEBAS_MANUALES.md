# Lista de verificación del examen — GYM CONTROL

Marca cada prueba después de ejecutarla en tu PC con MySQL y ambos servidores encendidos.

- [ ] Spring Boot muestra `Started GymControlApplication` en puerto 8080.
- [ ] Angular abre `http://localhost:4200` sin errores de compilación.
- [ ] Se puede iniciar sesión con el ADMIN inicial.
- [ ] Se puede crear, consultar, actualizar y eliminar una membresía sin socios.
- [ ] Se puede crear, consultar, actualizar y eliminar un socio sin pagos.
- [ ] Se puede crear, consultar, actualizar y eliminar un pago.
- [ ] Los registros se mantienen después de recargar la página.
- [ ] La sección Resumen refleja los registros guardados, sin cifras simuladas.
- [ ] No permite registrar dos socios con la misma cédula.
- [ ] No permite registrar dos membresías con el mismo nombre.
- [ ] No permite guardar pagos con monto cero o negativo.
- [ ] No permite asignar un socio a una membresía que no existe.
- [ ] No permite eliminar una membresía asignada a socios.
- [ ] No permite eliminar un socio que tiene pagos.
- [ ] Un usuario OPERADOR no puede consultar ni modificar /api/usuarios.
- [ ] Se puede consultar directamente en MySQL con database/02_consultas_verificacion.sql.

**Estado de pruebas en la creación del paquete**: se revisó la sintaxis de los archivos TypeScript y se generaron/inspeccionaron los diagramas e informe PDF. No fue posible compilar todas las dependencias Angular ni realizar una prueba completa Spring Boot + MySQL en este entorno. Esta lista está pendiente de verificarse en la PC del estudiante.
