# Guía de defensa — Gestión de gimnasio (4 entidades)

## Explicación en 30 segundos

Mi aplicación gestiona un gimnasio con cuatro entidades: Usuario, Membresía, Socio y Pago. En Spring Boot implementé controladores REST con GET, POST, PUT y DELETE; Spring Data JPA se comunica con MySQL. Angular utiliza HttpClient para consumir la API y mostrar formularios, tablas y un resumen. El login usa usuario y contraseña cifrada con BCrypt; el backend entrega un JWT y restringe la administración de usuarios al rol ADMIN. No hay correos ni datos simulados.

## ¿Por qué cuatro entidades?

- Usuario: autentica y controla permisos (ADMIN y OPERADOR), separado de los clientes del gimnasio.
- Membresía: define planes, duración, precio y estado.
- Socio: representa a la persona matriculada y se relaciona con su plan actual mediante `membresia_id`.
- Pago: deja evidencia de un cobro. Usa `socio_id` para relacionar cada pago con un socio.

Una membresía puede asignarse a muchos socios (1:N), y un socio puede tener muchos pagos (1:N). El usuario del sistema no es necesariamente un socio: por eso no tiene FK con las tablas de negocio. Esta decisión mantiene el alcance en cuatro entidades.

## Dos preguntas de backend y API REST

**1. ¿Para qué sirven las claves foráneas y cómo se aplican?** `socios.membresia_id` referencia `membresias.id` y `pagos.socio_id` referencia `socios.id`. MySQL impide referencias inexistentes; además la API consulta que existan antes de guardar. No dejamos borrar un plan usado ni un socio con pagos porque se perdería coherencia histórica.

**2. ¿Cómo trabaja una solicitud POST desde Angular hasta MySQL?** El formulario Angular prepara JSON, `ApiService` lo envía por HttpClient al endpoint. Spring Security valida JWT, el Controller recibe un DTO validado con Bean Validation, busca las FK por su repositorio JPA y guarda la entidad usando `JpaRepository.save`. JPA genera el SQL que ejecuta MySQL. La API responde JSON y Angular recarga la lista.

## Dos preguntas de frontend

**3. ¿Cómo consumes los datos reales de la API?** En `api.service.ts` uso `HttpClient` para GET, POST, PUT y DELETE contra `http://localhost:8080/api`. El componente `panel.component.ts` usa `forkJoin` para consultar socios, membresías y pagos. Los resultados guardados se representan en HTML con `@for`, y las operaciones vuelven a consultar la base.

**4. ¿Cómo funcionan las validaciones y las rutas protegidas?** El formulario utiliza `FormsModule`, `ngModel`, `required`, `min`, `minlength` y verifica `NgForm.invalid` antes de guardar. La API también valida y responde 400/409. `authGuard` controla la navegación; `jwtInterceptor` adjunta `Authorization: Bearer TOKEN` y el backend verifica permisos. Ocultar el menú Usuarios no es la seguridad principal: la restricción real está en Spring Security.

## Demostración en orden

1. Abrir NetBeans + CMD del backend, mostrar `Started GymControlApplication`.
2. Abrir Angular `localhost:4200` y acceder con el usuario admin.
3. Registrar plan, socio y pago; verificar las tres tablas.
4. Editar un registro, volver a cargar la página y mostrar persistencia.
5. Abrir MySQL Workbench y ejecutar `database/02_consultas_verificacion.sql`.
6. Mostrar tablas y claves: PK en todas y FK en socio y pago.
7. Crear usuario OPERADOR y explicar JWT/roles.
8. Explicar que el CRUD cumple GET, POST, PUT y DELETE en sus cuatro recursos.

## Preguntas adicionales que pueden hacerte

**¿Qué significa CRUD?** Create (POST), Read (GET), Update (PUT), Delete (DELETE).

**¿Qué es el diagrama ER?** Representa entidades y cardinalidades; aquí hay relaciones Membresía-Socio y Socio-Pago de uno a muchos.

**¿Qué es JPA?** Una especificación Java de persistencia; Spring Data JPA provee repositorios para trabajar con entidades sin escribir manualmente cada consulta SQL.

**¿Qué es CORS?** Es una política del navegador. El backend autoriza solicitudes del origen `http://localhost:4200` mientras corre en `localhost:8080`.

**¿Por qué BCrypt?** Porque almacena un hash de contraseña, no el texto original.

**¿Cuándo se usa 401 frente a 403?** 401 si la solicitud carece de autenticación válida; 403 si está autenticada pero no tiene el rol requerido.

**¿Por qué Usuario no tiene llave foránea?** Los usuarios son empleados/operadores de la plataforma, no necesariamente socios; separar ambas responsabilidades evita relaciones artificiales.

**¿Qué falta en un sistema empresarial completo?** Historial de inscripción a planes, vencimientos renovables y auditoría de operaciones. No se agregaron entidades porque el alcance elegido es de cuatro tablas.
