export type Rol='ADMIN'|'OPERADOR';
export interface Usuario{id:number;nombre:string;username:string;rol:Rol;activo:boolean}
export interface Membresia{id:number;nombre:string;descripcion:string;duracionDias:number;precio:number;activa:boolean}
export interface Socio{id:number;nombres:string;apellidos:string;cedula:string;telefono:string;fechaIngreso:string;activo:boolean;membresia:Membresia}
export interface Pago{id:number;socio:Socio;fechaPago:string;monto:number;metodoPago:'EFECTIVO'|'TRANSFERENCIA'|'TARJETA';observacion:string}
export interface LoginRespuesta{token:string;usuario:Usuario}
export type Seccion='resumen'|'socios'|'membresias'|'pagos'|'usuarios';
