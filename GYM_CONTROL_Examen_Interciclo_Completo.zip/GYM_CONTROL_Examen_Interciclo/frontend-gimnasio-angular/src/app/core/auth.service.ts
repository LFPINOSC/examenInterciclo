import {Injectable,inject,signal} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {tap} from 'rxjs';
import {LoginRespuesta,Usuario} from './models';
const URL='http://localhost:8080/api';
@Injectable({providedIn:'root'})
export class AuthService{
 private http=inject(HttpClient);
 private tokenKey='gym_access_token';private usuarioKey='gym_usuario';
 private recuperar():Usuario|null{try{return JSON.parse(sessionStorage.getItem(this.usuarioKey)||'null') as Usuario|null;}catch{return null;}}
 usuario=signal<Usuario|null>(this.recuperar());
 token(){return sessionStorage.getItem(this.tokenKey);}
 estaAutenticado(){return !!this.token()&&!!this.usuario();}
 login(username:string,password:string){return this.http.post<LoginRespuesta>(`${URL}/auth/login`,{username,password}).pipe(tap(r=>{sessionStorage.setItem(this.tokenKey,r.token);sessionStorage.setItem(this.usuarioKey,JSON.stringify(r.usuario));this.usuario.set(r.usuario);}));}
 cerrar(){sessionStorage.removeItem(this.tokenKey);sessionStorage.removeItem(this.usuarioKey);this.usuario.set(null);}
}
