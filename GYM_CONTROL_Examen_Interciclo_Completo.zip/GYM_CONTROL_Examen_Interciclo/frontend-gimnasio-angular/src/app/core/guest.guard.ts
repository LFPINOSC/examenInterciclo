import {inject} from '@angular/core';
import {CanActivateFn,Router} from '@angular/router';
import {AuthService} from './auth.service';
export const guestGuard:CanActivateFn=()=>{const a=inject(AuthService);return a.estaAutenticado()?inject(Router).createUrlTree(['/panel']):true;};
