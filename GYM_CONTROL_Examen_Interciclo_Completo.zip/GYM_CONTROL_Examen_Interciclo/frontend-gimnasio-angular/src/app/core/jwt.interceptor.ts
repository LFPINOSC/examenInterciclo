import {HttpInterceptorFn,HttpErrorResponse} from '@angular/common/http';
import {inject} from '@angular/core';
import {catchError,throwError} from 'rxjs';
import {Router} from '@angular/router';
import {AuthService} from './auth.service';
export const jwtInterceptor:HttpInterceptorFn=(req,next)=>{
 const auth=inject(AuthService),router=inject(Router),token=auth.token();
 const request=token?req.clone({setHeaders:{Authorization:`Bearer ${token}`}}):req;
 return next(request).pipe(catchError((error:HttpErrorResponse)=>{
  if(error.status===401&&token&&!req.url.endsWith('/auth/login')){auth.cerrar();void router.navigateByUrl('/login');}
  return throwError(()=>error);
 }));
};
