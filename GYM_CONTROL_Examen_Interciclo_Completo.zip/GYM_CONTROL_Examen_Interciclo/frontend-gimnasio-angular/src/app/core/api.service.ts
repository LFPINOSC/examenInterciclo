import {Injectable,inject} from '@angular/core';
import {HttpClient} from '@angular/common/http';
@Injectable({providedIn:'root'})
export class ApiService{
 private http=inject(HttpClient);private url='http://localhost:8080/api';
 listar<T>(ruta:string){return this.http.get<T[]>(`${this.url}/${ruta}`);}
 crear<T>(ruta:string,datos:unknown){return this.http.post<T>(`${this.url}/${ruta}`,datos);}
 editar<T>(ruta:string,id:number,datos:unknown){return this.http.put<T>(`${this.url}/${ruta}/${id}`,datos);}
 eliminar(ruta:string,id:number){return this.http.delete<void>(`${this.url}/${ruta}/${id}`);}
}
