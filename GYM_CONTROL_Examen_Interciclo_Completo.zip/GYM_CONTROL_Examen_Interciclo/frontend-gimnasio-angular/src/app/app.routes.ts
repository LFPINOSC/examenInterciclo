import {Routes} from '@angular/router';
import {authGuard} from './core/auth.guard';
import {guestGuard} from './core/guest.guard';
import {LoginComponent} from './pages/login.component';
import {PanelComponent} from './pages/panel.component';
export const routes:Routes=[
 {path:'login',component:LoginComponent,canActivate:[guestGuard]},
 {path:'panel',component:PanelComponent,canActivate:[authGuard]},
 {path:'',pathMatch:'full',redirectTo:'panel'},
 {path:'**',redirectTo:'panel'}
];
