import {Component,inject} from '@angular/core';
import {FormsModule} from '@angular/forms';
import {Router} from '@angular/router';
import {HttpErrorResponse} from '@angular/common/http';
import {AuthService} from '../core/auth.service';
@Component({selector:'app-login',standalone:true,imports:[FormsModule],templateUrl:'./login.component.html'})
export class LoginComponent{
 private auth=inject(AuthService);private router=inject(Router);
 username='';password='';cargando=false;error='';verClave=false;
 ingresar(){if(!this.username.trim()||!this.password){this.error='Completa usuario y contraseña';return;}
  this.cargando=true;this.error='';this.auth.login(this.username.trim(),this.password).subscribe({next:()=>{this.cargando=false;void this.router.navigateByUrl('/panel');},error:(e:HttpErrorResponse)=>{this.error=e.error?.mensaje||'No se pudo iniciar sesión. Revisa el servidor.';this.cargando=false;}});
 }
}
