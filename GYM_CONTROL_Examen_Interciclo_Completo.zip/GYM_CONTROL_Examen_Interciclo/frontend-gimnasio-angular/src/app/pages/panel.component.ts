import {Component,inject,OnInit} from '@angular/core';
import {FormsModule,NgForm} from '@angular/forms';
import {CommonModule} from '@angular/common';
import {HttpErrorResponse} from '@angular/common/http';
import {forkJoin} from 'rxjs';
import {Router} from '@angular/router';
import {ApiService} from '../core/api.service';
import {AuthService} from '../core/auth.service';
import {Membresia,Pago,Seccion,Socio,Usuario} from '../core/models';
@Component({selector:'app-panel',standalone:true,imports:[FormsModule,CommonModule],templateUrl:'./panel.component.html'})
export class PanelComponent implements OnInit{
 api=inject(ApiService);auth=inject(AuthService);private router=inject(Router);
 vista:Seccion='resumen';cargando=false;guardando=false;error='';exito='';busqueda='';
 socios:Socio[]=[];membresias:Membresia[]=[];pagos:Pago[]=[];usuarios:Usuario[]=[];
 modal=false;editandoId:number|null=null;formulario:any={};
 readonly menu:{clave:Seccion;icono:string;titulo:string}[]=[{clave:'resumen',icono:'▦',titulo:'Resumen'},{clave:'socios',icono:'♟',titulo:'Socios'},{clave:'membresias',icono:'◈',titulo:'Membresías'},{clave:'pagos',icono:'▤',titulo:'Pagos'},{clave:'usuarios',icono:'⚙',titulo:'Usuarios'}];
 hoy=this.fechaLocal();
 ngOnInit(){this.cargar();}
 get esAdmin(){return this.auth.usuario()?.rol==='ADMIN';}
 get titulos():Record<Seccion,string>{return {resumen:'Panel general',socios:'Gestión de socios',membresias:'Planes de membresía',pagos:'Registro de pagos',usuarios:'Control de usuarios'};}
 get subtitulos():Record<Seccion,string>{return {resumen:'Una vista general de la actividad del gimnasio',socios:'Consulta, registra y administra tus clientes',membresias:'Controla los planes, precios y vigencia',pagos:'Movimientos y cobros registrados',usuarios:'Credenciales y permisos del sistema'};}
 get ingresos(){return this.pagos.reduce((t,p)=>t+Number(p.monto||0),0);}
 get sociosActivos(){return this.socios.filter(s=>s.activo).length;}
 get membresiasActivas(){return this.membresias.filter(m=>m.activa).length;}
 private fechaLocal():string{const d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;}
 cargar(){this.cargando=true;this.error='';
  const r:any={socios:this.api.listar<Socio>('socios'),membresias:this.api.listar<Membresia>('membresias'),pagos:this.api.listar<Pago>('pagos')};
  if(this.esAdmin)r.usuarios=this.api.listar<Usuario>('usuarios');
  forkJoin(r).subscribe({next:(data:any)=>{this.socios=data.socios;this.membresias=data.membresias;this.pagos=data.pagos;this.usuarios=data.usuarios||[];this.cargando=false;},error:(e:HttpErrorResponse)=>{this.cargando=false;this.error=this.mensajeError(e);}});
 }
 seleccionar(v:Seccion){if(v==='usuarios'&&!this.esAdmin)return;this.vista=v;this.busqueda='';this.error='';this.exito='';this.modal=false;}
 salir(){this.auth.cerrar();void this.router.navigateByUrl('/login');}
 get filas():any[]{const base:any[]=this.vista==='socios'?this.socios:this.vista==='membresias'?this.membresias:this.vista==='pagos'?this.pagos:this.vista==='usuarios'?this.usuarios:[];
  const q=this.busqueda.toLowerCase().trim();return q?base.filter(x=>JSON.stringify(x).toLowerCase().includes(q)):base;
 }
 nuevo(){this.error='';this.exito='';this.editandoId=null;
  if(this.vista==='membresias')this.formulario={nombre:'',descripcion:'',duracionDias:30,precio:null,activa:true};
  if(this.vista==='socios')this.formulario={nombres:'',apellidos:'',cedula:'',telefono:'',fechaIngreso:this.hoy,activo:true,membresiaId:this.membresias.find(m=>m.activa)?.id??null};
  if(this.vista==='pagos')this.formulario={socioId:this.socios[0]?.id??null,fechaPago:this.hoy,monto:null,metodoPago:'EFECTIVO',observacion:''};
  if(this.vista==='usuarios')this.formulario={nombre:'',username:'',password:'',rol:'OPERADOR',activo:true};
  this.modal=true;
 }
 editar(item:any){this.error='';this.exito='';this.editandoId=item.id;
  this.formulario={...item};
  if(this.vista==='socios')this.formulario.membresiaId=item.membresia.id;
  if(this.vista==='pagos')this.formulario.socioId=item.socio.id;
  if(this.vista==='usuarios')this.formulario.password='';
  this.modal=true;
 }
 guardar(form:NgForm){if(form.invalid||this.guardando)return;
  const ruta=this.vista;if(ruta==='resumen')return;
  this.guardando=true;this.error='';
  const peticion=this.editandoId===null?this.api.crear(ruta,this.formulario):this.api.editar(ruta,this.editandoId,this.formulario);
  peticion.subscribe({next:()=>{this.guardando=false;this.modal=false;this.exito=this.editandoId===null?'Registro creado correctamente':'Cambios guardados correctamente';this.cargar();},error:(e:HttpErrorResponse)=>{this.guardando=false;this.error=this.mensajeError(e);}});
 }
 eliminar(item:any){if(!confirm('¿Seguro que deseas eliminar este registro? Esta acción no se puede deshacer.'))return;
  if(this.vista==='resumen')return;this.error='';this.exito='';
  this.api.eliminar(this.vista,item.id).subscribe({next:()=>{this.exito='Registro eliminado correctamente';this.cargar();},error:(e:HttpErrorResponse)=>this.error=this.mensajeError(e)});
 }
 private mensajeError(e:HttpErrorResponse){return e.error?.mensaje||e.error?.message||(e.status===0?'No se puede conectar al backend en localhost:8080':'Ocurrió un error al procesar la solicitud');}
 textoSocio(s:Socio){return `${s.nombres} ${s.apellidos}`;}
 dinero(valor:number|string){return '$'+Number(valor||0).toLocaleString('es-EC',{minimumFractionDigits:2,maximumFractionDigits:2});}
 cerrarAvisos(){this.error='';this.exito='';}
}
