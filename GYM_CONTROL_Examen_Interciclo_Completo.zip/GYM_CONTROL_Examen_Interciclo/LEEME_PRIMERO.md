# GYM CONTROL — Examen práctico interciclo 2026

**Tema asignado:** Gestión de gimnasio (estudiante N.º 18).  
**Tecnologías:** Java 21, Spring Boot 3.5.16, Angular 20, MySQL 8, Spring Security y JWT.  
**Entidades (exactamente 4):** Usuario, Socio, Membresía y Pago.  
**Correo electrónico:** No se utiliza Gmail, SMTP, verificación ni registro público.

## Carpetas

- `backend-gimnasio-springboot/`: abrir en **NetBeans 15** (proyecto Maven, `pom.xml`).
- `frontend-gimnasio-angular/`: abrir en **Visual Studio Code** (Angular).
- `backend-gimnasio-springboot/database/`: creación de DB y consultas para comprobar datos.
- `diagramas/`: entidad-relación y diagrama de tablas en PNG y PDF.
- `Informe_GYM_CONTROL.pdf`: análisis, diseño, API y defensa.
- `GUIA_DEFENSA.md`: explicaciones y preguntas para la presentación.

## 1. Requisitos

Java JDK **21**, MySQL Server **8**, NetBeans (o Maven instalado), Node.js compatible con Angular 20 (recomendado Node 22), npm y Visual Studio Code. Debe estar ejecutándose MySQL en `localhost:3306`.

## 2. Base de datos MySQL

Opción A: abre MySQL Workbench y ejecuta `backend-gimnasio-springboot/database/01_crear_base.sql` (crea DB y tablas).

Opción B: el backend tiene `createDatabaseIfNotExist=true` y `spring.jpa.hibernate.ddl-auto=update`, por lo que intenta crear DB y tablas automáticamente si el usuario tiene permisos. **No hace falta ejecutar ambas opciones**.

En el backend abre `src/main/resources/application.properties` y revisa:

```properties
spring.datasource.username=${DB_USER:root}
spring.datasource.password=${DB_PASSWORD:}
```

**No incluyas contraseñas en GitHub**: configura `DB_PASSWORD` como variable de entorno local de Windows o en la configuración de ejecución. La expresión `${DB_PASSWORD:}` significa que, si no existe dicha variable, usa contraseña vacía (solo funciona si la contraseña real es vacía).

**Por CMD de Windows, en la misma ventana antes de ejecutar el backend:**

```bat
set "DB_PASSWORD=TU_CLAVE_REAL_MYSQL"
```

No compartas esta clave por chat ni la subas al repositorio.

## 3. Iniciar backend Java 21 en CMD

En tu computadora, abre CMD, activa Java 21 en esa ventana (usa la ruta real del JDK):

```bat
set "JAVA_HOME=C:\Users\ASUS\AppData\Local\Programs\Eclipse Adoptium\jdk-21.0.12.101-hotspot"
set "PATH=%JAVA_HOME%\bin;%PATH%"
java -version
```

Entra a la carpeta del backend extraído (cambia la ruta si está en otra ubicación):

```bat
cd /d "C:\Users\ASUS\OneDrive\Escritorio\GYM_CONTROL_Examen_Interciclo\backend-gimnasio-springboot"
set "DB_PASSWORD=TU_CLAVE_REAL_MYSQL"
"C:\Program Files\NetBeans-15\netbeans\java\maven\bin\mvn.cmd" clean spring-boot:run
```

Comprueba que salga `Started GymControlApplication` y que Tomcat utilice el puerto **8080**. Deja CMD abierto. Si no tienes Maven instalado, usa el Maven incorporado de NetBeans como en el ejemplo anterior. El proyecto requiere JDK 21, no Java 20.

## 4. Iniciar frontend Angular en otra CMD

```bat
cd /d "C:\Users\ASUS\OneDrive\Escritorio\GYM_CONTROL_Examen_Interciclo\frontend-gimnasio-angular"
npm install
npm start
```

Abre **http://localhost:4200**. Deja abiertas las DOS consolas (backend y frontend). La primera ejecución de npm puede descargar paquetes desde Internet.

## 5. Acceso inicial

El sistema crea una única cuenta de administrador al primer inicio si la tabla de usuarios está vacía:

**Usuario:** `admin`  
**Contraseña inicial:** `Gym2026!`  
**Rol:** `ADMIN`

Esto **no es un modo de simulación**: el administrador se guarda en la tabla `usuarios` con su contraseña cifrada mediante BCrypt. Cambia la contraseña del administrador en la sección **Usuarios** después del primer ingreso. Si la tabla ya contiene usuarios, **no** se crea automáticamente otro administrador.

El operador (creado por un ADMIN en Usuarios) puede gestionar socios, planes y pagos, pero NO puede administrar usuarios.

## 6. Orden recomendado de pruebas

1. Inicia sesión con ADMIN.
2. Crea una **membresía** (por ejemplo, 30 días, $30); comprueba que aparece en la tabla.
3. Crea un **socio** y elige esa membresía.
4. Crea un **pago** asociado al socio.
5. Cambia valores con **Editar**, guarda y recarga el navegador; deben seguir en MySQL.
6. Comprueba la pantalla **Resumen** (cuenta de socios, planes y pagos; suma de montos).
7. Intenta eliminar una membresía asociada a un socio: la API debe rechazar la operación para proteger los datos.
8. Crea un usuario **OPERADOR**, entra con él y comprueba que no puede acceder al CRUD de usuarios.
9. Comprueba MySQL con el archivo `database/02_consultas_verificacion.sql`.

## 7. API REST

| Entidad | GET lista | GET uno | POST | PUT | DELETE |
|---|---|---|---|---|---|
| Membresía | `/api/membresias` | `/api/membresias/{id}` | `/api/membresias` | `/api/membresias/{id}` | `/api/membresias/{id}` |
| Socio | `/api/socios` | `/api/socios/{id}` | `/api/socios` | `/api/socios/{id}` | `/api/socios/{id}` |
| Pago | `/api/pagos` | `/api/pagos/{id}` | `/api/pagos` | `/api/pagos/{id}` | `/api/pagos/{id}` |
| Usuario (ADMIN) | `/api/usuarios` | `/api/usuarios/{id}` | `/api/usuarios` | `/api/usuarios/{id}` | `/api/usuarios/{id}` |

Además: `POST /api/auth/login` y `GET /api/auth/perfil`. Todas las rutas salvo el login usan header `Authorization: Bearer <JWT>`.

## 8. Publicar en el repositorio del profesor (AL FINAL)

El profesor indicó `https://github.com/LFPINOSC/examenInterciclo.git`. Repositorio y ramas pueden actualizarse durante el examen: confirma que tienes autorización para publicar.

```bat
cd /d "C:\Users\ASUS\OneDrive\Escritorio"
git clone https://github.com/LFPINOSC/examenInterciclo.git
cd examenInterciclo
git switch -c estudiante-18-mateo-gregorio-romero
```

Copia a esa carpeta el contenido del proyecto descargado, **no la carpeta `node_modules`, `dist` ni `target`**. Luego:

```bat
git add .
git commit -m "Examen interciclo gestion de gimnasio"
git push -u origin estudiante-18-mateo-gregorio-romero
```

Si el repositorio remoto está vacío y `git switch -c` crea una rama sin commits, es normal. Verifica `git branch` y `git status`.

## Observaciones de seguridad y alcance

- Proyecto académico local. No se han incluido credenciales MySQL personales ni claves SMTP.
- En un despliegue público, cambia `JWT_SECRET`, `ADMIN_PASSWORD` inicial y configura secretos fuera del repositorio.
- Un usuario con rol OPERADOR no ve el módulo Usuarios; además el backend impide peticiones a ese módulo.
- Las relaciones que protege el sistema son `membresia 1:N socio` y `socio 1:N pago`. `usuarios` es entidad independiente de autenticación.
- La tabla `socios` guarda su plan actual. Por la restricción de **cuatro entidades**, esta versión no guarda histórico de cambios de plan como entidad separada.
- El frontend consume exclusivamente la API REST: no hay registros de negocios inventados en pantalla.
